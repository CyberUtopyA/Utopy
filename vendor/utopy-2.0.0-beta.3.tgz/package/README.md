# UTOPY Runtime v1 · Micelio Vivo

Runtime de referencia para que personas, negocios, comunidades, objetos y máquinas puedan descubrirse, preguntar, responder, coordinar capacidades y registrar resultados sin convertir Market, MO, Mapa o Seed en una autoridad central.

## One protocol, any language

**UTOPY is defined by its protocol, not by its TypeScript implementation.** This Runtime is the current reference implementation. JavaScript, Python, PHP, Rust, Go, Java, Kotlin, C#, Swift, Dart, C/C++, embedded and future implementations can speak [UTOPY Wire Protocol v1](docs/WIRE_PROTOCOL.md) directly.

### Protocol

The common language: LivingEnvelope, canonical bytes, signatures, causality, privacy and portable conformance.

### Runtime

The complete TypeScript reference implementation: verification, Micelio, Node Emergence, Frequency, Discovery, consent, outcomes, Passport and Mind.

### SDK

Application convenience APIs. The SDK is an implementation of UTOPY; it is not UTOPY itself.

### Adapters

External bridges translate existing systems while preserving authority and provenance. UTOPY does not need to know every system in the world. It needs to define how a system can express who it is, what it can do, and how it relates.

## Community adapters

Anyone can build and publish an adapter without permission. There is no mandatory adapter registry. The public conformance suite verifies technical compatibility; it does not grant trust or endorsement. The community builds bridges. The protocol keeps them interoperable. See [Open adapters](docs/ADAPTERS.md) and [Building adapters](docs/BUILDING_ADAPTERS.md).

```text
EXTERNAL WORLDS
PLC ----- OPC-UA adapter --┐
ESP32 --- MQTT adapter ----┤
PHP ----- SDK/adapter -----┤
Python -- SDK -------------┤
Robot --- custom adapter --┤
                            ↓
                   UTOPY WIRE PROTOCOL
                            ↓
                     LivingEnvelope
                            ↓
                     Node Emergence
                            ↓
                       Living Nodes
                            ↓
              Micelio / Frequency / Mind
```

## Living Financing

The Runtime distinguishes financing offers, accepted agreements, signed settlement
commitments, guarantees, provider-verified settlement and delivery. Partial buyer/lender
contributions settle the seller independently of later loan repayments. Conservative
delivery policies, beneficiary protection and provider-operation dedupe are available
through `utopy/liquidity` and `runtime.sdk.settlement`.
See [Living Financing](docs/LIVING_FINANCING.md) for the contracts and host adapter boundaries.

## Continuidad Viva + Living Space

Authority trust, sovereign node handoff/ACK, private-by-default access and
non-executable Living Space capability manifests extend the same signed
`LivingEnvelope`. They remain transport-neutral and do not activate sensitive
actions. See [Continuidad Viva + Living Space](docs/CONTINUITY_LIVING_SPACE.md).

## Node Emergence

Verified identity, capability, state and relationship evidence becomes a deterministic local `LivingNodeProjection`; raw DVs remain the facts. Explicit manifests emerge immediately, while manifestless devices emerge progressively and later reconcile safely. Runtime and SDK expose `emergence`, capability/relationship queries, bridge discovery and evidence explanations. See [Node Emergence](docs/NODE_EMERGENCE.md).

## Principios

- **Los nodos son autoridad.** Seed es bootstrap/relay/fallback, no dueño de los hechos.
- **La red puede repetir transporte; la realidad no se repite.** Dedupe causal + idempotencia económica.
- **Capabilities antes que categorías.** Un carpintero y una CNC pueden ofrecer `cut.sheet` sin estar hardcodeados por industria.
- **Outcomes antes que scores.** NodeMind aprende de hechos firmados, no de un Trust Score central.
- **Consentimiento para compromisos.** Descubrir y preparar puede ser automático; gastar, firmar, revelar o comprometer recursos puede requerir autorización.
- **Oral/multimodal first.** Voz, imagen, video, símbolos y gestos son expresiones de primera clase; una traducción nunca reemplaza el original.
- **Liquidity no es una moneda UTOPY.** Coordina dinero, cripto/DeFi, crédito, materiales, trabajo, máquinas, transporte, energía, derechos y otros recursos.

## Capas

```text
Experiencias: Market · Falcon · MO · Mapa · PWA · máquinas
                         ↓
                    UTOPY Runtime
 identidad · policies · mind · memoria · outcomes · consent
                         ↓
                       Micelio
 direct · LAN · WebRTC · Hyperswarm · Seed · offline/store-forward
```

## Inicio rápido

```ts
import {
  createUtopyRuntime,
  InMemoryTransport,
  createIdentity,
} from "@utopy/runtime";

const identity = await createIdentity({ actorId: "actor:ana", nodeId: "node:taller.ana" });
const transport = new InMemoryTransport("ana");
const runtime = await createUtopyRuntime({ identity, transports: [transport] });

runtime.capabilities.register({
  code: "fabricate.wood",
  visibility: "public",
  availability: "available",
});

await runtime.start();
await runtime.sdk.ask("fabricate.wood", { territory: "Salto del Guairá" });
```

## IA Simbiótica soberana

`SymbioticMind` es una capa opcional sobre `NodeMindV1`. Trabaja con `LivingEnvelope`, prepara resultados y, por defecto, no ejecuta ni publica nada:

```ts
const runtime = await createUtopyRuntime({
  identity,
  transports: [transport],
  symbioticMind: {
    autonomy: "SUGGEST",
    flags: {
      enabled: true,
      shadow: true,
      planner: true,
      recursiveResonance: true,
      composer: true,
      mandates: true,
      safeAuto: false,
      outcomeLearning: true,
    },
  },
});

runtime.onObservation((observation) => {
  console.log(observation.symbiotic?.explanation);
  console.log(observation.symbiotic?.prepared); // propuestas, no publicaciones
});
```

El razonamiento es intercambiable mediante `ReasoningProvider`. El Runtime incluye `RuleReasoner`; un adapter local, remoto, humano, Python o específico de una máquina debe declarar dónde se ejecuta. Contenido privado, `noShare` o `noAITraining` no se entrega a un razonador remoto.

Una inferencia conserva provenance y confianza, pero nunca se eleva automáticamente a hecho. Sólo envelopes verificables y outcomes firmados alimentan la memoria factual local. Ver `docs/SYMBIOTIC_MIND.md`.

## Composición Viva

`LivingComposition` representa propuestas portables y versionadas de intent →
capabilities → participantes → condiciones → evidencia → outcomes. Usa envelopes,
autoridad y consentimiento existentes; no ejecuta workflows. Ver
`docs/LIVING_COMPOSITION.md` y `@utopy/runtime/composition`.

## Transportes incluidos

- `InMemoryTransport`: pruebas/local.
- `BroadcastChannelTransport`: pestañas/browser del mismo origin.
- `WebRTCDataChannelTransport`: envuelve un `RTCDataChannel` ya señalizado.
- `HyperswarmTransport`: adaptador opcional por import dinámico; instalar `hyperswarm` en runtimes Node que lo usen.
- `SeedWebSocketTransport`: fallback compatible con un Seed WebSocket.
- `OfflineQueueTransport`: cola local/store-forward.

Micelio elige rutas por prioridad y puede entregar redundante cuando se solicita; dedupe impide procesar el mismo hecho dos veces.

## Seguridad

El runtime firma envelopes con **ES256 / P-256** mediante WebCrypto. La identidad pública viaja como JWK y la privada nunca debe publicarse. Ver `docs/SECURITY.md`.

## Estado

Este ZIP es una **implementación de referencia v1 funcional y compilable**, pensada para integrarse progresivamente con los repos existentes. No reemplaza por sí sola los adapters productivos específicos de Seed, MO o MS Market ni una auditoría de seguridad/cripto externa antes de custodiar valor real.
