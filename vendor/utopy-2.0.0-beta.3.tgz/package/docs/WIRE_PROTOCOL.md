# UTOPY Wire Protocol v1

## Living financing extension profile

The additive v1 profile documents `finance.agreement`, `finance.accept`,
`settlement.commitment`, `settlement.commitment.update`, `payment.provider.attestation`,
`repayment.schedule`, and `installment.outcome` in [Living Financing](LIVING_FINANCING.md).
Their portable schemas live in `schemas/v1/<kind>.schema.json` and are generated from
`src/liquidity/settlement.schema.ts`, with parity tests. Signature/authority and
thread/chain/root remain on the unchanged LivingEnvelope. Participant scope is required
for transactional use; opaque beneficiary/provider references protect sensitive data.

Settlement amounts use safe integer accounting units agreed consistently across all
linked contracts. `SETTLED` is evidence-derived and is prohibited as a commitment
update assertion. No schema-valid commitment alone proves settlement or legal guarantee.
Signed positive/negative simulation vectors are in `conformance/v1/settlement-commitment-*.json`.
Conformance checks portable structure/crypto; host trust, consent, mandate, rail evidence
and whole-transaction validation are separate mandatory contextual checks.

UTOPY is the protocol, not its TypeScript SDK. This document fixes the portable wire contract implemented today by the reference Runtime. A Python, Rust, PHP, Go, Java, C/C++, embedded or future implementation can interoperate without npm.

## Version and negotiation

The version token is `utopy/1`. A peer advertises `supportedVersions` and may advertise `preferredVersion`. Peers select a shared preferred token; otherwise they return `unsupported-version` plus their supported list. A future v2 does not invalidate v1. The TypeScript helper is `negotiateProtocol`.

`protocolVersion` is an allowed top-level extension. Legacy v1 envelopes that omit it remain v1-compatible. New implementations SHOULD emit it.

## LivingEnvelope

The normative shape is `schemas/v1/living-envelope.schema.json`; `src/protocol/types.ts` is the reference implementation. Required fields are `id`, `kind`, `revision`, `contentHash`, `sourceActorId`, `createdAt`, `hop`, `maxHops`, `visitedNodeIds`, `payload`, and `authority`. IDs are opaque, case-sensitive UTF-8 strings. They are never rewritten by relays.

- `id` + `revision` identifies a revision. `authority|id|revision` is its causal dedupe key.
- `createdAt` and `expiresAt` are RFC 3339/ISO-8601 UTC strings. Invalid dates are rejected; an expired envelope is rejected.
- `rootId`, `parentId`, `respondsTo`, `threadId`, and `chainId` preserve causality and composition.
- `sourceRefs` may be an extension array of immutable envelope/DV IDs. A translator MUST append provenance, never erase it.
- `sourceActorId` names the actor; `sourceNodeId` names the emitting node; `authority` is the cryptographic claim checked against `ownership` and local trust policy.
- `scopes` are `public`, `participants`, `community`, `custodians`, or `private`. Participant-scoped interchange MUST list `participants`.
- `hop` cannot exceed `maxHops`; `visitedNodeIds` and `routeTrace` prevent routing loops. Relays alter only routing fields.
- `policy.restrictions` carries `noShare`, `noAITraining`, `noReproduce`, `noDerivative`, and `noLocationDisclosure`.

`kind` and capability codes are open namespaced strings, not closed enums. Core names are reserved by the protocol; third parties SHOULD use stable namespaces such as `acme.robot.grip`. An extension SHOULD publish a schema/version URI and compatibility hints near its payload.

## Canonical UTF-8 JSON

The algorithm below is the exact behavior of `canonicalize` in the reference Runtime:

1. Input MUST already be a JSON value. `undefined`, functions, symbols, `NaN`, infinities, bigint, implicit Date objects and sparse arrays are prohibited.
2. `null`, booleans, strings and numbers use ECMAScript `JSON.stringify` representation. Strings use JSON escaping. Implementations MUST reject integers outside the interoperable safe range `[-9007199254740991, 9007199254740991]`; use decimal strings for larger values.
3. Arrays retain order and concatenate canonical members with `,` inside `[]`.
4. Object keys are sorted ascending by UTF-16 code units, exactly as JavaScript default string sort. Each key uses JSON string encoding, followed by `:` and its canonical value, joined with `,` inside `{}`.
5. Encode the resulting string as UTF-8 without BOM. Dates are strings supplied by the producer; canonicalization performs no date conversion.

This describes the existing implementation, not a new canonicalizer. See `conformance/v1/canonicalization-vectors.json`.

## Content hash and signature

For the content hash, deep-copy the envelope; remove `ownership`; set `contentHash` to `""`, `hop` to `0`, and `visitedNodeIds` to `[]`; remove `routeTrace`; canonicalize and UTF-8 encode; then SHA-256 and base64url-encode without padding.

For the signature payload, deep-copy the completed envelope; remove `ownership`; set `hop` to `0` and `visitedNodeIds` to `[]`; remove `routeTrace`; canonicalize and UTF-8 encode. Sign using ECDSA P-256 with SHA-256 (`ES256`). The wire signature is the 64-byte fixed-width `r || s` WebCrypto representation, base64url without padding. The public key is a P-256 JWK in `ownership.publicKeyJwk`; `keyId` identifies the credential.

Trust in a key is local policy separate from signature validity. Translation never grants authority. The non-secret vector `conformance/v1/envelope-valid.json` includes payload, exact canonical string, content hash, public JWK and valid signature.

## Dedupe, replay and TTL

Receivers validate shape/hash, inspect dedupe, verify signature, mark dedupe, then run effects. Exact key is `id|revision|contentHash`; causal key is `authority|id|revision`. Same causal key with another hash is a conflict. Domain operations may add idempotency keys. Expired input is rejected. A relay stops when TTL expired, `hop >= maxHops`, or it already appears in `visitedNodeIds`.

## Privacy, consent and binary content

Scope is not authority. `private`, `participants`, `noShare`, and `noLocationDisclosure` constrain projection and relay. Implementations MUST NOT broaden scope during translation. A write/action requires applicable consent, mandate and safety policy; receipt is not proof of execution.

Binary content is referenced with a content-addressed URI/ref, media type, byte length and digest. If inline bytes are unavoidable, identify base64url explicitly. The signed envelope covers the reference and digest.

## Forward compatibility, limits and errors

Unknown fields and namespaced kinds/capabilities are preserved for signature/hash and otherwise ignored when safe. Reject an unknown critical extension, unsupported version, malformed core field, invalid hash/signature, expiry, invalid scope, replay, or exceeded hop limit. Unknown optional fields do not invalidate v1.

Recommended defaults are maximum 8 hops and bounded dedupe/evidence caches. Frame limits are transport capabilities; large content uses references. Stable error strings include `missing-core-field`, `revision`, `hop`, `visited`, `expired`, `content-hash`, `signature`, `duplicate`, `causal-conflict`, `unsupported-version`, and `participants-required`.

“UTOPY Protocol Compatible v1” means only that an implementation passed public v1 conformance. It is not certification, legal approval, security guarantee, trust score, or endorsement.
