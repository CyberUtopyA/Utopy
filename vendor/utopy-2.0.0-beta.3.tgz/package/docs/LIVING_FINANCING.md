# Living Financing and seller settlement safety

“Una financiación no es segura porque fue propuesta. Es segura para el vendedor cuando existe una obligación verificable y, finalmente, un outcome de liquidación.”

“UTOPY puede descubrir cómo hacer posible una relación, pero no debe fingir que algo ocurrió antes de que exista evidencia.”

## Three economic relationships

The purchase binds buyer and seller. The loan binds buyer and financier. The settlement obligation binds financier/authorized settlement authority and seller. After the seller receives the required funds, later repayment belongs to the buyer/financier relationship. The seller does not collect installments unless it is also the financier under the agreement.

The same contracts cover a seller financing its own goods or financing another node's goods. Reserve, cooperatives, merchants and other lenders use identical identity, capability, consent and provider checks. No name or node ID earns priority or trust.

## Consent and lifecycle

1. A financier signs an existing `finance.offer` (or supported financing kind) carrying `FinancingTerms`.
2. The financier signs `finance.agreement`, referencing that exact offer hash, an economic route, seller payment request, funding sources and repayment terms.
3. Buyer and seller each sign `finance.accept` over the agreement ID, envelope reference and exact content hash. The financier's agreement signature is its acceptance. The agreement is effective only with all three signatures. It is an unaccepted proposal until then.
4. The specified economic authority signs `settlement.commitment` after those acceptances. A commitment cannot stand alone.
5. Provider evidence establishes separate actual settlements. Only their verified sum pays the seller.
6. Seller delivery is represented independently by `delivery.outcome`. Repayment continues through `repayment.schedule` and `installment.outcome`.

New agreement, acceptance, commitment, commitment update, schedule and delivery authorization kinds are sensitive in ConsentEngine. SymbioticMind can prepare and explain. These APIs do not accept debt, sign, execute money transfers or publish automatically. An application must use its existing consent workflow before signing.

The seller accepts the exact route, beneficiary, net amount, fees, timing, funding composition and delivery policy. Publishing inventory is not consent to changed economics. The buyer cannot substitute a destination. An operator cannot replace principal, seller, financier or beneficiary: signatures bind the full contract even when a mandate permits collecting or verifying receipts.

## Commitment state machine

`PROPOSED → COMMITTED → CONDITION_PENDING → READY_TO_SETTLE → SETTLING → SETTLED`

`COMMITTED → READY_TO_SETTLE` is also allowed. `SETTLING → FAILED → SETTLING` represents retry. Early revocation or expiry is permitted only by the contract. A signed `settlement.commitment.update` references the original commitment hash, previous event ID, increasing sequence, and condition evidence. `READY_TO_SETTLE` requires proofs from each condition's designated authority. Duplicate events are harmless; conflicting sequences are rejected.

`SETTLED` is derived exclusively from verified provider operations. It cannot be asserted through a commitment update. Expiry blocks reliance on an unpaid promise; it does not erase an already verified payment. A provider failure leaves funds pending. Verification failures yield `UNKNOWN` with `safeToDeliver:false`.

Before delivering against a guarantee, the host must atomically persist a seller-signed `delivery.authorize` with agreement hash and relied-upon commitment IDs in its existing ledger. Include it on subsequent projection. Later revocation is rejected after this reliance, after an evidenced partial settlement, or after entry into `SETTLING`. No inferred legal guarantee or automatic ownership transfer is created.

## Delivery policies and consumer view

`SETTLED_ONLY` is the conservative default: the seller delivers after the required verified net settlement. `VALID_COMMITMENT_ALLOWED` permits early delivery only when every unpaid financing source has a live signed commitment from an authority whose `settlement.guarantee` capability is verified; unfunded buyer downpayments must still settle. `EXTERNAL_ESCROW_ALLOWED` requires a verified funded external escrow and explicit custody policy.

`SettlementSafetyView` separates:

| Safety | Meaning |
|---|---|
| `DO_NOT_DELIVER` | Missing, expired, revoked, insufficient or invalid evidence |
| `GUARANTEE_PRESENT` | Payment is backed under an explicit policy; it is not settled |
| `SAFE_TO_DELIVER` | The required funds actually settled |
| `UNKNOWN` | Verification unavailable; never authorizes delivery |

`safeToDeliver` is the policy decision, so it can be true with `GUARANTEE_PRESENT` under a seller's explicit early-delivery policy. `status` remains `BACKED`, never `SELLER_SETTLED`, until funds arrive. Neutral UI mappings: `SEARCHING` → buscando financiación; `BACKED` → pago respaldado; `SETTLING` → liquidando; `SELLER_SETTLED` → liquidado; `ACTION_REQUIRED` → acción necesaria. Delivery remains a separate outcome.

## Amounts, composition and repayment

The settlement v1 profile uses positive safe integer accounting amounts. All contracts, routes, provider proofs and funding sources MUST use the same explicitly agreed currency denomination. The core performs no currency conversion or rounding. The PYG vectors use guaraníes; adapters for fractional currencies must normalize the whole agreement/route to an agreed integer accounting unit before using this profile. Existing economic routes outside this profile retain their existing number semantics.

Funding sources identify contributor, buyer/financier role, amount, currency, due date, obligation reference and, for financed sources, commitment ID. Source IDs and obligation IDs are distinct and unique. Their amounts must sum exactly to `sellerRequiredSettlement`; financed sources sum exactly to principal. A ₲500000 buyer contribution plus ₲1600000 loan settles ₲2100000, while the repayment principal remains ₲1600000. Sources may settle through several independent provider operations; surplus on one source cannot substitute a different source's obligation.

`repaymentScheduleFromAgreement` preserves the agreed total, installments and dates with deterministic installment IDs. `projectRepayment` accepts signed, independently verified installment payments and derives pending/settled/overdue. It has no reference that can mutate the seller projection. Default handling, collateral enforcement, leasing or retention of title require separate contracts/policies. No collection, repossession or ownership mutation runs here.

## Provider, cash and external escrow boundary

The preferred flow is financier → payment provider/rail → seller. UTOPY coordinates evidence and does not hold funds.

`payment.provider.attestation` carries provider, operation reference, funding source, commitment when applicable, order/agreement/payment request, amount/currency, merchant, opaque beneficiary reference, timestamp, status, verification reference and source refs. `requested`, `sent`, `acknowledged`, `executed` and `failed` are not `settled`.

`SettlementVerification.trust` must bind authority, keyId AND actual public JWK against the existing identity policy, including revocation. `hasCapability` must verify the exact authority's advertised capability at the relevant time. `verifyProvider` is mandatory and must independently check the original provider operation, authenticated callback or bank/payment rail evidence against the agreement and source: merchant, destination, amount, currency, payer/source, operation identity, timestamp and final settlement state. A signed assertion alone is insufficient. Never derive a true result from an untrusted `verified:true` flag.

Delegated verification requires `authorizeOperator`. Cash additionally requires `settlement.collect` authorization and a signed verified receipt. The host adapter must consult the existing MandateBook/current revocations and restrict operations to the exact agreement, participants, budget and destination. Selecting cash in a UI does not create a receipt.

`regulatedExternalCustody` and `custodialOrAggregator` require an external compliance reference plus `authorizeCustody`. Escrow also requires `escrow.hold`, a current signed `escrow.offer` bound to the agreement, and independent `verifyEscrow` proof of funded custody. These callbacks attest a permitted external service; they do not license UTOPY or establish UTOPY escrow.

## APIs and existing ledger integration

```ts
import { projectSellerSettlement, evaluateSellerDeliverySafety,
  prepareSettlementPaymentOutcomes, projectRepayment } from "utopy/liquidity";

const projection = await projectSellerSettlement(input);
const sellerView = projection.view;
// input contains the signed evidence bundle and host-local verification adapters.
// Rebuild from the application's existing durable evidence ledger.
```

The SDK exposes the same helpers through `runtime.sdk.settlement`. `financingPartyView` provides role-specific local data for buyer, seller and financier. Authenticate the role before exposing it. Buyer sees price, downpayment, principal, total and schedule; seller sees expected amount and settlement authority; financier sees its buyer obligation and settlement responsibility. Route cost explanations remain in the existing economic helpers.

`prepareSettlementPaymentOutcomes` returns unsigned `payment.outcome` envelopes only after successful provider verification. IDs derive deterministically from provider and operation; thread, chain and root are preserved. The host signs/persists/publishes explicitly using its existing OperationIdempotency and transaction mechanism. No new store or money executor is created.

Runtime dedupe distinguishes consent authority, commitment ID/sequence and provider operation, preserving multiple payments for the same order. Projection dedupes by provider/operation rather than webhook ID and detects conflicting financial data. Include the complete authorized evidence set; dropping historical receipts, revocations or delivery authorizations would make any reconstruction incomplete. Across process restarts, durable atomic idempotency and uniqueness of agreement/commitment/provider operation must be enforced in the host's existing ledger. In-memory transport dedupe is not a substitute for it.

## Liquidity, fees and privacy

EconomicRoute can reference a financing source, payment rail, commitments, delivery policy and repayment. `MerchantEconomicPolicy.requireVerifiableSettlement` with host-verified `EconomicContext.settlementRouteRefs` makes missing seller settlement a route constraint. This set must describe order-bound verified contractual settlement paths, not an offer's self-declaration; discovery can still show unaccepted offers as proposals.

Margin Guard remains active: minimum net, provider fees, financing fees and settlement delay are checked against the seller's local policy. Costs distinguish payer `buyer`, `merchant`, and `financier`; an absorbed fee is not charged automatically to the seller. `settlement` is a separate cost kind. Tax/withholding remains separate from processor, financing and settlement costs; no tax settlement is invented.

Financing contracts and attestations require participant scope. Use opaque references for bank destinations and provider evidence. Keep income, IDs, private terms, tokens, full provider payloads and repayment history out of public catalogs, frequencies and passports. Consumers may include permitted outcome refs in Passport or notify meaningful state transitions through Frequency. These helpers do not publish pulses or notifications on polls.

## Portable contract and verification

`src/liquidity/settlement.schema.ts` is the canonical schema source. Versioned JSON artifacts in `schemas/v1` are checked for exact parity by tests. ES256 and hashing remain the existing Wire Protocol algorithms; causal IDs and authority/signature live on LivingEnvelope rather than being copied into a second signature contract.

Signed public simulation vectors are `conformance/v1/settlement-commitment-valid.json` and `settlement-commitment-invalid.json`. Conformance validates schema, canonical bytes and signature. Transaction acceptance additionally requires the contextual agreement/consent/provider checks in `projectSellerSettlement`; a standalone schema-valid commitment is not evidence that an actual purchase was financed.

Tests cover split settlement, no duplicate principal, guarantees, expiry, revocation, beneficiary substitution, provider callback duplication/conflicts, cash and mandates, escrow, privacy, repayment separation and portable schema parity. Production provider integrations, durable host transactions and external legal/compliance determinations remain responsibilities of their respective adapters/operators.
