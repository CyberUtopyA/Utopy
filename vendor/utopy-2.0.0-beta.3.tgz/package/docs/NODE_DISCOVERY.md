# Descubrimiento de Nodos Vivos

`utopy.node.manifest` es un `LivingEnvelope` firmado que relaciona `nodeId`, revisión, autoridad, capacidades libres y endpoints opcionales. Discovery es memoria local; no existe registro global.

```ts
await utopy.discovery.observeManifest(signedManifestEnvelope);
const nodes = utopy.discovery.listKnownNodes();
```

La identidad deriva de firma y authority binding. `name`, `handle` o un `sellerNodeId` aislado nunca suplantan al nodo. Revisiones antiguas, firmas inválidas y manifests expirados se rechazan.

Las capacidades son strings o estructuras serializables. El Runtime no impone industrias, HTTP ni un modelo comercial. Los adapters legacy permiten migración gradual, pero el dato adaptado debe firmarse antes de adquirir autoridad.
