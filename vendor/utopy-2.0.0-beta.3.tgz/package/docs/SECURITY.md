# Seguridad y soberanía

1. **Firma portable:** ES256 sobre representación canónica del envelope sin `ownership.signature`.
2. **Authority:** el runtime verifica que el `keyId` de ownership coincida con una clave pública aceptada para la autoridad.
3. **Consentimiento:** acciones sensibles se clasifican `auto | prepare | ask-human | deny`.
4. **Privacidad:** no propagar CI, deuda, comprobantes, datos bancarios, identity links o conocimiento protegido a peers no autorizados.
5. **Expresión cultural:** una expresión puede declarar `noShare`, `noAITraining`, `noReproduce`, custodios y audiencia.
6. **Seed:** nunca re-firma hechos como si fuera el nodo autor.
7. **DeFi/finanzas:** el runtime planifica y enruta ofertas; no custodia fondos ni autoriza automáticamente operaciones monetarias.

Antes de operar dinero real, cripto, crédito o infraestructura crítica, realizar auditoría externa de seguridad y cumplimiento aplicable.
