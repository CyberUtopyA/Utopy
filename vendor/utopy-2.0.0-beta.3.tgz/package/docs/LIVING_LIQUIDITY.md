# Living Liquidity

## Seller settlement safety

Living Financing adds signed finance agreements/acceptances and settlement commitments
on top of the existing routes. See [Living Financing](LIVING_FINANCING.md) for
`projectSellerSettlement`, `evaluateSellerDeliverySafety`, provider attestations,
partial settlement, guarantees, repayment and external escrow policies.

Financing accepted, payment backed, settling, seller settled and delivered are distinct.
The seller stays settled if the buyer later misses installments. No Runtime custody
or automatic acceptance/publication is introduced. `runtime.sdk.settlement` exposes
the evaluation and preparation helpers over the application's existing evidence ledger.

EconomicRoute may include settlement agreement/commitment/rail/repayment references.
Merchant policy can require a verified settlement path through `requireVerifiableSettlement`
and host-local `settlementRouteRefs`. Margin Guard still applies. Costs add `settlement`
as a separate kind and `financier` as an explicit fee payer; absorbed costs do not
reduce merchant net. `regulatedExternalCustody` requires the same explicit external
compliance evidence as other custodial routes, plus the settlement adapter checks.

“UTOPY no necesita conocer de antemano todas las formas posibles de cooperación.
Necesita permitir que necesidades y capacidades se expresen suficientemente bien para que nuevas relaciones puedan emerger.”

“Liquidity no pregunta solamente cuánto dinero falta.
Pregunta qué falta para que esto pueda ocurrir.”

## Economic Routes

The existing `utopy/liquidity` export adds `evaluateEconomicRoute`,
`discoverEconomicRoutes`, `acceptedEconomicRoutes`, `discoverFinancingOffers`,
`explainEconomicRoute` and `economicTradeoffs`. They prepare alternatives only.
There is no execution, custody, automatic credit approval or mandatory network toll.
Existing `planLiquidity`, `LiquidityAdapter` and source contracts remain usable.

An `EconomicRoute` binds order, merchant, beneficiary and tax identity. It contains
provider, method, amount/currency, individually evidenced costs, settlement delay
(milliseconds), expiry, conditions and source references. Provider, fixed and
variable charges are represented as individual quoted `EconomicCost.amount`s;
the adapter, not the core, converts its published pricing into a quoted amount.
Unknown charges are not zero. `costsComplete: true` is an explicit adapter/config
assertion covering the quoted non-tax costs and any supplied known tax effects.
Absent tax context means a before-tax estimate only, never tax exemption.
Values must use one currency and its normal denomination throughout a route.
The core does not convert currencies or quote FX rates.

## Margin Guard and private merchant policies

Evaluate inside the merchant's trusted local/server boundary. Policies never come
from the buyer. `minimumNetAmount` applies after known withholding/tax effects
when available, otherwise before tax. Processor ceiling, allowed methods/currencies,
settlement delay and contribution margin are independent constraints.

Known cost violations yield `UNVIABLE`; missing evidence, unknown costs, missing
settlement information or compliance context yield `UNKNOWN`. Only `VIABLE`
routes can enter `acceptedEconomicRoutes`. Known violations take precedence.
Missing estimates stay absent. No global economic or borrower score is generated.

`costBasis`, `additionalCosts`, `minimumContributionMargin`, evaluations and
merchant explanations are private/local. `acceptedEconomicRoutes` returns a
buyer-safe explicit projection, excluding margin, costs, policy and tax identity.
Conditions must themselves be authored for sharing with the buyer. Never publish
the complete evaluator input as a catalog, map or passport record.

Gross minus processor and other known merchant costs equals estimated net before
tax. Known tax/withholding is separate. Contribution margin is calculated only
when both cost basis and additional costs are explicitly supplied; it is not
profit. Estimates carry `estimate: true`, `taxSettlement: false`.

## Provenance and authorization boundary

`EconomicContext` is trusted merchant-local adapter state, never an untrusted DV.
Its `sourceRefs`, `taxContextRefs` and `complianceRefs` must contain only evidence
the host already validated for this order, currency, identities, scope and expiry.
Adapters may use merchant config, verified quotes, signed provider offers and tax
adapters. Caller-supplied flags or a signed offer from an unknown key are not trust.
The mandatory trust callback must bind authority, keyId AND public JWK to the
existing identity/discovery trust policy. Core has no commercial key registry.

`authorizeEconomicRoute` verifies provider and merchant signatures and binds the
merchant's `liquidity.route.accept` to offer ID, content hash, route ID, expiry and
all order economic identities. Changing beneficiary, merchant, tax identity,
amount, currency or the quote invalidates approval. The acceptance must have been
created under the existing ConsentEngine/Mandates policy. The resolver never
creates consent. Merchant routing approval is not the buyer's contract acceptance.
Signed `payment.offer`/`payment.route`/`liquidity.route.offer` are supported.
Adapters translate existing provider contracts to this additive shape; existing
payment protocols and Market deployments are not silently migrated.

## Financing and composition

`FinancingTerms` requires principal, currency, total repayment, dated schedule,
expiry, conditions, financing authority, contract reference and required consents.
Pricing-structure adapters must obtain a complete quote before exposing selectable
financing here. No inferred installments, free financing or approval.
Schedule amounts must equal total repayment. Buyer total includes repayment
difference exactly once; conflicting explicit financing charges are rejected.

Seller, Reserve and third-party offers use the same signed financing discovery.
Terms must be signed by the financing authority and cover the requested principal
and currency. Seller inventory and merchant identity remain independent of lender.
A composed money route carries explicitly permitted contract legs with evidence,
currency and exact amounts summing to the purchase: e.g. 500000 now plus 1600000
financed. Nonmatching totals or prohibited composition reject the proposal.
Referenced contracts and financier evidence must be verified by the host; route
economics is not a replacement contract-validation engine.

## Non-custodial principle and UTOPY Reserve

Direct buyer → provider → merchant settlement is the preferred dimension exposed
by `economicTradeoffs`, alongside speed, privacy, availability, reversibility and
provider constraints. There is no global ranking or identity-based priority.
`custodialOrAggregator` requires an external compliance capability/policy reference;
Runtime neither grants a license nor implements jurisdictional regulation.

UTOPY network is free of mandatory network commissions or tokens. Reserve is an
ordinary Living Node discovered through the same capabilities and trust rules.
There is no fallback to Reserve and no special nodeId check. It may earn explicit,
voluntarily accepted financing spread, leases, asset usage, infrastructure fees,
material/energy sales or other resource revenue. It participates only as a party
required by that particular authorized relationship.

## Tax adapters

`TaxQuoteAdapter` advertises `tax.quote`, `tax.withholding.quote`, `accounting.record`.
Processor, commercial, tax, withholding, financing, FX and logistics costs are
separate categories. Quotes reference order/tax identity/currency and evidence.
Deduplication uses cost IDs, rejecting conflicting duplicates. No tax rates,
provider fees, beneficiary disguises, transaction suppression, artificial sales
splitting or income reclassification are implemented.

## Resource composition

Money, materials, labor, machines, transport, energy, space, knowledge, compute,
reuse and future resource kinds retain their own units. `planLiquidity` validates
required unit, currency, material, capability and territory and respects expiry,
availability, deadlines and explicit composition prohibitions. Capacity is consumed
across all need items, avoiding reuse or duplicate source IDs. This is a proposal,
not a reservation. Host validation must supply real available sources.
Legacy unspecified composition remains proposal-only; contract execution always
requires explicit compatible agreements and consent. New economic money legs
require `compositionAllowed: true` and contract evidence.

`proposeJointProcurement` preserves each contributing need/item and composes a
proposal against the shared source budget. It does not establish a central market.
A machine capacity or circular-material offer can be supplied by an open adapter
as a normal source; no conversion into money is required.

## Consent, idempotency and outcomes

Evaluation/discovery is repeatable and side-effect-free. Settlement and financing
acceptance continue through the existing ConsentEngine, Mandates and
OperationIdempotency using stable order/contract operation keys. No new settlement
executor or store was created. Hosts needing crash durability must persist their
existing operation ledger; an in-memory guard alone is not durable settlement.
SymbioticMind can explain/prepare these results, never approve credit, sign
contracts or transfer money. `payment.outcome`, `financing.outcome`,
`delivery.outcome`, `work.outcome`, `asset.use.outcome` stay separate signed facts.
Passport consumers use permitted outcome references; private financial payloads
must not be copied to public passports.

## Verification and rollout

Run `npm test` in the Runtime repository. `tests/living-liquidity.ts` tests margin
states, missing costs, tax separation, quote signatures, immutable beneficiary,
privacy projections, ordinary Reserve discovery, composite contracts and resource
capacity. All economic examples are simulations; no funds move.
The source package has to be published/installed through the normal deployment
process before MS Market or external nodes consume these new exports.
