# UTOPY Web Push

Web Push sólo despierta un dispositivo después de una decisión `PUSH` local. No transporta el hecho ni texto publicitario:

```json
{"kind":"frequency.wake","frequencyId":"…","reference":"…","revision":1}
```

El cliente despierto resuelve la referencia y recupera el hecho por Runtime/Micelio.

Contratos firmados:

- `push.subscription.register`
- `push.subscription.remove`
- `frequency.wake.request`

El sidecar desplegable está en `deploy/utopy-frequency-push`. Es independiente del Seed, usa VAPID persistente y almacena únicamente subscriptions, binding actor/node/device, modo y dedupe mecánico. No guarda frecuencias, perfiles, productos, pagos, conversaciones ni comportamiento.

No existe endpoint genérico para enviar notificaciones. `SeedFrequencyWakeAdapter` queda como adapter opcional futuro para reenviar requests firmados cuando un target está offline; no modifica el Seed actual.
