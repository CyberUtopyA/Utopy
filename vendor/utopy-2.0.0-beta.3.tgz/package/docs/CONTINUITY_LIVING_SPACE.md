# Continuidad Viva + Living Space

These contracts extend the existing `LivingEnvelope`; they do not introduce a
second DV, identity, Runtime or transport.

## Trust is policy, not signature validity

`authority.trust` carries `utopy.authority-trust/1`. Its envelope is ES256
signed, but a consumer must provide an already configured issuer trust callback.
A self-signed or cryptographically valid projection is never a trust anchor by
itself.

The projection binds authority, key id and public JWK and carries monotonic key,
device and mandate revocations. `AuthorityRegistry` supports JWK pinning,
expiry and irreversible local revocation. Foundation may operate one trust
projection, but applications may use another compatible issuer or their own
local trust evidence. Seed is not part of the trust decision.

Recommended flow:

1. Pin an issuer by configuration, portable evidence or an explicit local act.
2. Verify signature, audience, expiry and revision with
   `verifyAuthorityTrustEnvelope`.
3. Apply only the verified payload with `applyAuthorityTrust`.
4. Preserve the previous verified revision to reject revocation rollback.

## Sovereign handoff

`context.handoff` carries `utopy.context-handoff/1`; the receiver answers with a
separately signed `context.handoff.ack` carrying
`utopy.context-handoff-ack/1`.

A handoff contains canonical references, not copied profiles or application
state. It has a target node audience, a short TTL, nonce, purpose, requested
capabilities and optional consent reference. It is always participant-scoped.
`authorize`, `execute` and delegated actions require a consent reference whose
current validity is checked by the receiving host.

Transport delivery is not an ACK. An ACK binds the exact handoff id, revision,
content hash and nonce. It confirms validation/acceptance by the target node; it
does not by itself authorize a sensitive operation.

`HandoffReplayGuard` is the reference in-memory nonce guard. Durable hosts must
persist equivalent consumed-nonce state in an actor/node partition until expiry.

## Living Space capabilities

`living.capability.manifest` carries `utopy.living-capability/1`. It describes:

- lifecycle and semantic capability code;
- accepted intentions and produced outcomes/evidence;
- optional voice and 2D/2.5D/3D/AR modes;
- presentation references;
- permissions, effects, privacy and execution policy.

The contract contains no executable source, remote module, package or handler.
Spatial assets are data declared by media type and size. A host decides whether
to load them according to device capabilities and local policy.

Sensitive execution remains subject to the existing consent, mandate and
LivingComposition authorization gates. Publishing a capability never activates
it.

## Privacy and portability

New envelopes without explicit scopes default to `private`. Legacy beta.1
envelopes without scopes remain shape-compatible but `effectiveScopes` also
treats them as private. `canAccessEnvelope` and `storagePartitionKey` provide the
reference actor/node isolation rule; persistent adapters must enforce an
equivalent partition.

Micelio transports the same signed envelopes through direct, LAN, WebRTC,
Hyperswarm, Seed or offline/store-forward routes. No contract requires
Foundation or Seed to be online.

## LivingComposition compatibility

LivingComposition remains `utopy.living-composition/1` and is exported from the
root package and `utopy/composition`. Continuity handoffs reference a composition
envelope; they do not embed or fork a second composition schema.

Consumers on `2.0.0-beta.1` must move to the Runtime release containing the
existing `composition` export. During rollout they may continue to discover
composition DVs without enabling activation.

The first package version containing these continuity contracts is
`2.0.0-beta.3`; `utopy.living-composition/1` itself is unchanged.

## Adoption order

1. **Foundation:** configure an issuer key and publish audience-bound trust
   projections; do not make Foundation the only possible trust anchor.
2. **MO:** replace permissive signature callbacks with AuthorityRegistry trust,
   then consume handoffs and emit ACKs. Advertise its existing capabilities with
   Living Capability manifests.
3. **MS Market:** upgrade from beta.1, verify trust projections, send handoffs and
   wait for ACK. Keep current URL/local bridges as a fallback during observation.
4. **GE/MT/FEDA:** adopt the same manifests and handoffs; physical effects must
   retain explicit consent or mandate gates.
5. Remove a legacy bridge only after telemetry proves equivalent signed
   continuity. Do not automatically enable Runtime, Mind or sensitive actions.

## Remaining host responsibilities

- secure key storage and recovery;
- durable replay storage across restarts when required;
- trust-source distribution and operational key rotation;
- retention/deletion policy for private envelopes;
- UI consent and human-readable effect presentation;
- transport authentication and abuse controls in addition to envelope trust.
