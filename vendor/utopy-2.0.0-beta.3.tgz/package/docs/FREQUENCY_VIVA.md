# Frecuencia Viva

Frecuencia es el estado temporal y causal de una intención viva. El hecho original (`need.publish`, `capability.offer`, `expression.publish`, etc.) se publica una vez; los pulsos posteriores sólo transportan `frequencyId`, secuencia, revisión, tiempo y expiración.

```ts
const frequency = await utopy.frequency.createNeedFrequency({
  rootIntentId: need.id,
  capabilities: ["material.offer"],
  ttlMs: 60 * 60_000,
});
await utopy.frequency.pulse(frequency.frequencyId);
await utopy.frequency.resolve(frequency.frequencyId);
```

Estados: `alive`, `paused`, `resolved`, `expired`. Un identificador resuelto o expirado no revive. Subfrecuencias heredan `rootId`, `parentId`, `threadId`, `chainId` y TTL. Micelio sigue siendo el transporte; Frequency no crea red ni store factual.

`LegacyPresenceAdapter` proyecta `presence.signal ↔ Frequency` durante la migración. `frequency.match` es inferencia local. Sólo `AttentionPolicy` puede elevar una coincidencia a `PUSH`, y los pulsos nunca consumen presupuesto de interrupción.

`frequency.qr()` crea una referencia `utopy://frequency/...` íntegra y sin payload privado. Resolverla devuelve el estado local conocido, incluyendo terminalidad.
