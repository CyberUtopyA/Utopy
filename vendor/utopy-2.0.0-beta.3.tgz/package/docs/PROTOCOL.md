# UTOPY Protocol v1

## LivingEnvelope

Todo hecho usa el mismo sobre causal y de autoridad. `payload` cambia según `kind`.

Campos centrales:

- `id`, `kind`, `revision`, `contentHash`
- `threadId`, `chainId`, `rootId`, `respondsTo`
- `sourceActorId`, `sourceNodeId`
- `targetNodeId`, `participants`
- `traits`, `scopes`
- `createdAt`, `expiresAt`
- `hop`, `maxHops`, `visitedNodeIds`
- `authority`, `ownership`

## Gramática mínima

- `capability.ask`, `capability.offer`
- `need.publish`, `need.match`
- `quote.request`, `quote.offer`
- `work.request`, `work.offer`, `work.accept`, `work.execution`, `work.outcome`
- `material.need`, `material.offer`
- `finance.request`, `finance.offer`
- `route.need`, `route.offer`
- `relationship.request`, `relationship.outcome`
- `liquidity.need`, `liquidity.route.offer`, `liquidity.route.accept`, `settlement.plan`, `settlement.outcome`
- `expression.publish`, `passport.issue`

Las industrias no forman parte del core: aparecen como `capabilities`, `traits` y contratos de dominio.

## Repetición y causalidad

El mismo envelope puede llegar por varios transportes. Se considera igual por `id + revision + contentHash`. Las operaciones económicas deben además imponer sus propias claves idempotentes (`orderId`, `workId`, `paymentId`, etc.).

## Privacidad

`scopes` son políticas de routing, no cifrado por sí mismas. Para contenido sensible se recomienda cifrado end-to-end a participantes además de scopes.
