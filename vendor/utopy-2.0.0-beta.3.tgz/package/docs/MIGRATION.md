# Migración desde el core UTOPY existente

El runtime v1 **no exige reemplazar** `NodeMind`, `p2p-layer`, Seed, Micelio, Market o MO de una vez.

## P2P actual

El `p2p-layer` existente ya selecciona WebRTC/Hyperswarm/LAN/Offline y puede convivir con este runtime. Durante migración use `ExistingBusTransport` para envolver el bus actual y mover primero el **LivingEnvelope + dedupe + firma + capabilities**.

## NodeMind actual

El NodeMind histórico conserva memoria simbólica, resonancias y aprendizaje de vecinos. `NodeMindV1` del runtime es deliberadamente pequeño y determinista: procesa envelopes operativos y aprende de outcomes. Puede conectar el NodeMind avanzado como policy/agent opcional después, sin convertirlo en autoridad.

## Orden recomendado

1. Envolver transporte actual con `ExistingBusTransport`.
2. Firmar/validar `LivingEnvelope` en bordes.
3. Configurar confianza de autoridad; una firma válida no basta por sí sola.
4. Activar dedupe transversal.
5. Migrar capabilities/ask/offer.
6. Adoptar `context.handoff` + ACK en shadow, manteniendo el bridge legacy.
7. Migrar needs/quotes/outcomes.
8. Habilitar direct peer y dejar Seed como fallback.
9. Conectar memoria avanzada/IA como asesor, no como requisito.

## Symbolic dictionary and Living Form source contract

projectReasoningForm now returns one utopy.living-form/1 object instead of an array.
Use form.fields, form.missing and field.valid; pass installed declarations with optional
inputSchemas. SymbioticMindConfig.reasoningContext is exported in the public types.
Business keyword inference is replaced by explicit host declarations and aliases.
Use signed SymbolicDictionaryProjection verification with AuthorityRegistry and actual
consent checks for portable dictionary DVs; raw dictionary maps remain trusted-host-only.
See [SYMBOLIC_FORMS.md](SYMBOLIC_FORMS.md) for revision, revocation and adoption requirements.

Outcome learning now requires SymbioticMindConfig.learningConsent(source, identity).
Enabling a learning flag alone no longer authorizes learning; absent consent fails closed
for the existing NodeMind and SymbioticMind memories. Host consent checks must be current
and actor/node-specific; noAITraining remains a veto.
