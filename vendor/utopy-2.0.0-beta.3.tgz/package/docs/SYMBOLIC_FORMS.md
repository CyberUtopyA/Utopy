# Local symbolic dictionary and Living Form

The public root and utopy/mind exports include projectReasoningForm, LivingFormProjection,
LivingFormField, ReasoningContext, SymbioticMindConfig and the signed symbolic dictionary APIs.
SymbioticMindConfig.reasoningContext(identity) supplies the local host projection. No new runtime,
executor, network importer or capability loader is introduced.

## Authorized symbolic dictionary

SymbolicDictionaryProjection uses protocol utopy.symbolic-dictionary/1. It carries actorId,
optional nodeId, monotonically increasing revision, expiresAt and expressions. Each expression
carries expressionId, the original expression, locale, canonical code, aliases, sourceRefs,
revision, confidence, authority, scopes, an actor-bound learning consent reference, expiration
and active/disabled/revoked status. Locale is preserved metadata: multilingual matching uses
Unicode phrases and host-provided aliases, including Spanish, Portuguese, Guarani and mixed text.
It is deterministic matching, not general natural language understanding.

Use createSymbolicDictionaryEnvelope(identity, projection) to create a private signed LivingEnvelope.
Use verifySymbolicDictionaryEnvelope(envelope, { actorId, nodeId, authority, consentAllows, prior })
before giving its returned object to ReasoningContext.symbolicDictionary. Authority is the existing
AuthorityRegistry with the issuer's exact public key pinned. consentAllows must check the actual
consent reference, actor, scopes and current revocation state against the host's consent policy.
A consent reference by itself and a valid signature by itself grant no trust. Issuer authority is
bound to the projected node (or actor when no node exists). Foreign actor/node projections,
untrusted keys, tampering, expired projections and sem.tell announcements fail verification.

Only objects returned by verification are recognized; deserialized metadata must be verified again.
Verified handles use isolated snapshots, reject mutation as a source of new meanings, and stop
resolving after key revocation or a newer verified dictionary revision. The verification cache is
local to the supplied AuthorityRegistry and actor/node/issuer partition. Concurrent revisions fail
closed. Hosts must persist the last accepted signed DV and supply prior after restart to prevent
rollback across process restarts. There is no global learning store or automatic gossip import.

For a consented correction, increment projection and expression revisions, update expression/aliases
and provenance, sign and verify again. To disable or revoke an expression, publish the corresponding
status in the next private signed revision. Revocation is terminal for that expressionId; disabled
expressions can be re-enabled in a later authorized revision. Removed expressions must remain as
versioned tombstones. A changed or revoked consent must produce a fresh authorized projection
before reuse; consent is checked at verification time, not polled from a remote service.
Portability transports the signed DV; import still enforces the same actor/node partition and local
trust/consent policy. Moving to another node requires an explicit authorized re-projection.

ReasoningContext.dictionary remains a compatibility input for trusted local host aliases. It is
not a network DV format and performs no signature verification. Never pass network dictionaries
or another actor's private aliases through it. New integrations should use symbolicDictionary.
Expressions and explicit capability references resolve only codes declared by the host through
capabilities, declaredCapabilities or full execution declarations. No expression installs a handler
or changes the Core. Business/profession keyword rules have been removed: hosts declare their own
codes and aliases. The interpreter preserves the original text/transcript, including whitespace.

## Living Form

projectReasoningForm(envelope, interpretation, context) now returns one serializable object with
protocol utopy.living-form/1, formId, sourceRef, actorId, optional nodeId, intent, capabilities,
fields, permissions, effects, limits, missing, valid and proposalOnly: true.
This replaces the previous array of partial capability forms. Migrate callers from forms[0] to
form, and use form.missing / field.valid for clarification. SymbioticMind records this projection
as a private cognitive proposal and prepares questions only for missing or invalid fields.

Declarations are validated using the existing LocalCapabilitySandbox declaration validator.
Each field identifies its capability and name, carries optional serializable schema, required,
known, optional value and valid. CapabilityExecutionDeclaration.inputSchemas is an optional map
for declared input names. It supports string, number, integer, boolean, object and array types,
required, enum, numeric bounds and string length bounds. Schemas are intentionally a bounded
local subset, not an arbitrary executable JSON Schema plugin. Existing name-only declarations
continue to require each input. Host-authorized context.inputSchemas provides fallback metadata;
installed declaration schemas take precedence. Invalid schemas fail validation.

context.knownValues supplies authorized DV values; explicit human inputs override those values.
Zero and false are retained. Only declared fields are projected; unknown capabilities cannot produce
valid forms. context.resourceLimits constrains capability scope, execution count, duration, output,
network, storage, budget, territory, frequency and validity dates without widening host bounds.
Permissions/effects come from declarations. Ambiguous duplicate versions cannot produce a valid form.
No projection invokes a handler, invents a value, mutates the request or grants authorization.
A form's valid flag concerns the proposal; final viability belongs to the existing simulation gate.

After human corrections, re-project the revised request. Map known field values into the existing
CompositionInput and use LivingCompositionSDK.sign with an actual consent or mandate reference.
Use the existing revision API for subsequent composition corrections. The LocalCapabilitySandbox
and LivingCompositionEngine enforce installed handlers, schemas, simulation, signed authorization,
permissions, effects, limits, evidence and verified outcomes. Source tests demonstrate this complete
flow with no transports, LLM, Market, Studio or central server. Voice recognition itself remains a
host/device concern; Runtime accepts the resulting transcript locally.

Learning of aliases occurs only through verified consented dictionary revisions. Outcome learning
requires SymbioticMindConfig.learningConsent(source, identity) to verify current consent for the
source and actor/node and return true. Missing consent, callback failure and revoked consent fail
closed for both existing NodeMind and SymbioticMind learning paths. Disabling the outcomeLearning
feature or flag preserves its scope; noAITraining remains a veto and no private dictionary is shared
between runtimes. Observing an outcome is separate from learning it. This feature enables no production autonomy.

## Validation and package artifacts

npm run typecheck checks without emit. npm run test:source runs the Runtime suite against actual
sources and the symbolic dictionary/form/flow tests without a build (the source runner uses Node 23+
experimental TypeScript transformation). The emitted package retains the existing Node >=20 target.
Only after source tests pass, npm run build refreshes dist; npm test checks the compiled Runtime.
No npm publishing, network code loading or production automation is required or performed.
