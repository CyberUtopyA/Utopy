# Living Composition v1

`LivingComposition` is a portable, signed proposal that connects an intent to
capabilities, participants, declarative conditions, evidence requirements and
outcomes. It uses the existing `LivingEnvelope`, ES256 ownership, authority,
scopes, causal IDs and transport. It is not a workflow engine and contains no
executable expressions.

The payload protocol is `utopy.living-composition/1`; its envelope kind is
`composition.publish`. Capability codes and outcome kinds are open strings, so a
person, node, machine, adapter, manual action or capability that does not exist yet
can participate without profession-specific Core code.

`proof/signature` is the existing `LivingEnvelope.ownership` ES256 proof; it is
not duplicated inside the payload and therefore covers canonical payload plus
envelope authority, revision and integrity fields exactly once.

The canonical contract exposes top-level `inputs` and `requiredCapabilities`.
Inputs and per-step inputs are JSON data only; functions, executable expressions,
package references and source strings are invalid.

## Lifecycle

- `runtime.sdk.composition.prepare(...)` creates an unsigned, unpublished proposal.
- `sign(...)` signs locally without routing; `LivingCompositionEngine.save(...)`
  stores the immutable revision in the node's configured local state.
- `preview(...)` returns the structured “understood intent”, step list and bound
  simulation, always with `publishesAutomatically: false`.
- `create(...)` signs and shares revision 1 through the caller's Runtime.
- `revise(...)` keeps `compositionId`, increments revision and binds the exact
  predecessor envelope ID, revision and content hash.
- `fork(...)` creates a new identity and preserves signed source lineage. It rejects
  `noDerivative` sources.
- `missing(...)` compares required step capabilities with the local CapabilityRegistry.
- `outcome(...)` creates a signed `composition.outcome` for one assigned step.
- `projectComposition(...)` derives pending/partial/completed/failed state from
  verified outcomes; it performs no step and triggers no effect.
- `combineCompositionInputs(...)` namespaces combined forms and retains each signed
  source revision/hash in `composedFrom`.
- `share(...)` emits a separately signed redacted `composition.share`; it excludes
  inputs, evidence, authorization references, credentials and participant refs.

Every published composition carries `proposalOnly: true` and a signed authorization
reference (`explicit-consent` or `mandate`). This reference is evidence, not a global
permission oracle: the host must verify the referenced consent/mandate under its
existing policy before accepting effects. The SDK requires the local composition
authority for revisions and the assigned participant authority for outcomes.
An AI may prepare or suggest a composition; Core never lets the proposal itself
execute work, money movement, machine control or arbitrary code.

## Conditions and evidence

Conditions use only `exists`, `equals`, `not-equals`, `in`, `gte` and `lte` over
portable operand references. Runtime records them but does not evaluate arbitrary
logic. A completed step must cite every signed condition attestation listed by that
step and satisfy its required evidence kind, optional authority and schema reference.
Condition meaning remains a domain policy decision; structural verification does
not claim that a real-world condition is true. Before every execution, the host's
`verifyCondition` policy must independently attest every referenced condition.
Dependencies likewise require a verified outcome reference through
`verifyDependency`; a caller-provided “completed” boolean is never sufficient.

## Simulate, authorize, execute

`LocalCapabilitySandbox` accepts only handlers installed by trusted host code. A
network envelope can name a capability but cannot install source, evaluate a script,
load a URL/package or modify Core. Each declaration fixes inputs, outputs, effects,
permissions, network/storage needs, resource ceilings, reversibility, risks and an
optional cost upper bound.

`simulateComposition(...)` is mandatory before activation. It validates graph and
inputs, resolves local and discovered capabilities, reports external steps, effects,
permissions, risks, costs and missing providers, and blocks permission, network,
storage or resource expansion. Money/debt require a bounded matching budget. Physical
machinery with repeated execution requires an explicit frequency window. Money and
debt steps also declare their portable value claim, independently from adapter fees.

Activation uses a signed `composition.authorize` bound to the exact composition ID,
revision and content hash. It narrows steps, capabilities, budget, frequency,
territory, time window, expiry and executions. The existing consent/mandate verifier
runs at activation and before every step, so revocation stops new effects. A revision
never inherits another revision's activation.

`LivingCompositionEngine` executes only locally assigned steps. Every step passes
the policy gate and installed declaration. Calls emit `EXECUTING`, then `SUCCEEDED`,
`FAILED` or `CANCELLED`; a handler return is not success unless evidence verifies and
output stays within limits. Reversible handlers may emit evidenced `ROLLED_BACK`.
Signed `composition.outcome` envelopes are accepted by the existing Living Passport
projection, observed by SymbioticMind as outcomes, and—when visibility is
`participants`—travel through the existing Micelio Runtime transport.
Deactivation stops execution while preserving signed history. Safe version rollback
means deactivating, simulating and freshly authorizing the older signed revision.
The state store rejects two different signed payloads for the same ID/revision and
the engine rejects concurrent activation of two revisions of one composition.

Each node in a distributed composition authorizes only its participant steps.
Cross-node completion derives from independently signed outcomes; no coordinator gets
global authority.

Full composition envelopes may only use the declared input privacy (`private` or
`participants`). Private compositions, authorizations, execution evidence and
outcomes use `recordLocal`, which signs and persists without transport routing.
Broader sharing always uses the separately signed redacted `composition.share`.

The JS registry is a host-code trust boundary, not process isolation. Adapters that
are not fully trusted still require an OS/container/worker sandbox and brokered
network/storage credentials outside Core.

`verifyCompositionEnvelope` verifies payload/envelope binding, content hash and
signature. `verifyCompositionRevision` and `verifyCompositionFork` additionally
verify both linked envelopes and their exact lineage. `verifyCompositionOutcome`
checks the composition version/hash, assigned participant authority and signed
evidence. Callers supply their existing authority trust callback; a valid signature
alone does not make a key trusted.

The language-neutral schemas are:

- `schemas/v1/living-composition.schema.json`
- `schemas/v1/composition.outcome.schema.json`
- `schemas/v1/composition.authorization.schema.json`
- `schemas/v1/composition.execution.schema.json`
- `schemas/v1/composition.simulation.schema.json`
- `schemas/v1/capability.execution.schema.json`

Composition, authorization, execution and outcome kinds participate in Runtime
conformance checks. The public API is exported
from `@utopy/runtime/composition` and the root package.

Canonical principle: UTOPY does not let the network blindly reprogram nodes. Nodes
learn new ways of acting through verifiable, bounded, versioned and authorized
compositions.
