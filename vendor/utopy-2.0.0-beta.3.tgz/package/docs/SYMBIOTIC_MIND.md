# SymbioticMind

`SymbioticMind` aporta cognición local sin crear un coordinador central, un transporte nuevo ni un store global. Usa exclusivamente `LivingEnvelope` y las APIs públicas del Runtime.

## Ciclo

```text
observar → interpretar → descomponer → preguntar → componer
        → preparar propuesta → pedir consentimiento → observar outcome
```

Cada ciclo devuelve `records`, un grafo opcional, envelopes `prepared`, una explicación humana y si requiere consentimiento. En shadow, nada preparado se publica.

## Tipos cognitivos

- `observation`: algo recibido por el nodo.
- `inference`: interpretación con `sourceRefs`, reasoner, confidence y fecha.
- `proposal`: alternativa todavía no aceptada.
- `decision`: decisión explícita.
- `outcome`: resultado verificable.
- `fact`: sólo fuente verificable; nunca se deriva automáticamente de una inferencia.

## Autonomía

- `OBSERVE`: sólo observa.
- `SUGGEST`: explica y sugiere.
- `PREPARE`: construye envelopes sin publicarlos.
- `SAFE_AUTO`: únicamente acciones públicas, reversibles, no sensibles y habilitadas por flag.
- `DELEGATED`: necesita un `mandate.grant` firmado, vigente y dentro de límites.

`shadow=true` tiene precedencia sobre cualquier nivel. `safeAuto=false` es el default.

## Memoria soberana

La memoria es local al proceso/nodo y no calcula score global:

- `episodicMemory`
- `relationshipMemory`
- `capabilityMemory`
- `outcomeMemory`
- `privatePreferences`

El aprendizaje principal proviene de outcomes firmados y verificados. `noAITraining` excluye el contenido de memoria de aprendizaje.

## ReasoningProvider

Un provider implementa `interpret`, `classify`, `decompose`, `plan`, `propose` y `explain`, y declara `execution` como `local`, `remote`, `human` o `machine`. El Runtime no importa SDKs de modelos.

Las políticas se evalúan antes de invocarlo. Un provider remoto no recibe contenido privado, `noShare` o `noAITraining`.

## Composición y consentimiento

`SymbioticComposer` combina ofertas de capacidades, presupuestos, materiales, financiación y rutas. Produce candidatos, tradeoffs, faltantes y consentimientos requeridos; no ejecuta settlement ni acepta propuestas.

Acciones de dinero, crédito, contrato, compra, producción, identidad, ownership o conocimiento protegido pasan por `ConsentEngine`. Un mandato firmado puede representar consentimiento delegado sólo para las acciones y límites expresos que contiene.

## Protección de la red

La resonancia recursiva conserva `rootId`, `threadId`, `chainId` y `parentId`; respeta expiración, hop limit, nodos visitados, dedupe causal y `maxBranches`. Los referrals sólo exponen capacidades públicas y referencias mínimas.
