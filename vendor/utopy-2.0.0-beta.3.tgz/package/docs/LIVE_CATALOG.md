# Catálogo Vivo

`node.catalog.announce` anuncia una fuente pull firmada. Debe usar HTTPS, compartir origin con el endpoint y, si el manifest declara origin, coincidir con él. Se bloquean localhost, redes privadas, credenciales embebidas, TTL vencido y anuncios sobredimensionados.

Push de catálogo admite contratos genéricos:

- `mt:producto`
- `service.offer`
- `material.offer`
- `machine.offer`
- `capability.offer`

Cada DV debe estar firmado por la autoridad del manifest. Un seller o producer declarado que no corresponda al manifest se rechaza. Catálogo Vivo no pertenece a Market; cualquier nodo puede anunciar o consumir según scopes y políticas.
