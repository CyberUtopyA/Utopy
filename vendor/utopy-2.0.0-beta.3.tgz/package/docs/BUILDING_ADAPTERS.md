# Building a UTOPY adapter

## Prerequisites

Read `WIRE_PROTOCOL.md`, use the v1 schemas and run all public vectors. Any language with canonical JSON, SHA-256 and ES256/P-256 can implement an adapter; TypeScript and npm are optional.

## Workflow and example

1. Receive and validate external input.
2. Resolve a stable subject reference without claiming ownership.
3. Map an open namespaced kind/capability and preserve source provenance.
4. Build the envelope, calculate canonical content hash, then sign the canonical signature payload.
5. Apply privacy, TTL, hop and consent policies.
6. Test invalid signatures, retry, replay, round-trip, unknown fields and offline recovery.

```text
FakeTemperatureProtocol { device: "A1", celsius: 23.2 }
  -> capability/measurement LivingEnvelope
     payload.subjectRef = "fake:A1"
     payload.translatedBy = ["community.fake-temperature"]
```

The Core does not know FakeTemperatureProtocol. Node Emergence consumes its valid generic evidence.

## Manifest, signing and semantics

Optionally publish signed `utopy.adapter.manifest` per `schemas/v1/adapter-manifest.schema.json`. Advertise bridge capabilities for decentralized discovery. Use `requires`, `produces`, `consumes`, `compatibleWith`, and `broader` sparingly; your extension schemas remain in your repository.

The adapter key attests to translation, not source ownership. Never publish private keys, tokens, PLC credentials or payment secrets. Preserve scope, `noShare` and `noLocationDisclosure`.

## Read versus write

Separate permissions. A write adapter validates mandate/consent, external preconditions and machine safety, then emits only the strongest outcome it proves. For PLCs, robots, vehicles and payments, an LLM suggestion is a proposal only.

## Conformance

Consume `conformance/v1/*.json` and implement `docs/WIRE_PROTOCOL.md`. With the reference Runtime: `npm run conformance < conformance/v1/envelope-valid.json`. External CI can produce the same shape:

```json
{"protocol":"utopy/1","compatible":true,"passed":11,"failed":0}
```

Fail CI when `compatible` is false. Passing is not security certification.

## Packaging and publishing anywhere

```text
my-utopy-adapter/
  src/
  tests/
  utopy.adapter.json
  README.md
```

This layout is optional; only the wire contract matters. Version adapter and supported protocols independently. Publish through any ecosystem or firmware channel. No permission, registry entry, merge or manual approval is required.

