# Open adapters

## 1–3. Definition, boundary and core

An adapter translates another system to or from UTOPY Wire Protocol. It is not UTOPY Core, a trust authority, or an integration requiring approval. Core owns LivingEnvelope, signatures, Node Emergence, Discovery, Frequency, consent, outcomes, Passport and capability semantics. OPC-UA, Modbus, MQTT, Siemens, Shopify, WooCommerce, Bancard, PIX and device code remain external.

Anyone may distribute an adapter through npm, PyPI, crates.io, Composer, Maven, GitHub, Git, ZIP or firmware. Its creator owns it. There is no mandatory app store, registry, approved list or Market listing.

## 4–5. Read and envelope output

A read adapter observes external facts, maps stable subject references and capability/state/measurement semantics, signs or forwards an attestation under the correct authority, and emits valid LivingEnvelopes. It preserves source refs and never invents success or identity.

## 6–9. Authority, translation, attestation and identity

Translation never grants authority. Distinguish device/source authority, adapter authority, gateway attestation and ordered `translatedBy` provenance. Use `observedBy`, `attestedBy`, `translatedBy`, `visitedAdapters`, `chainId` and source refs as extensions. “Gateway X observed Device Y” is not “Gateway X is Device Y.” Stable signed subject refs drive emergence; names are hints.

## 10–13. Emergence, capabilities, privacy and consent

Adapters produce evidence; Node Emergence produces projections. Capability codes are open namespaces. Semantic hints can declare `broader`, `compatibleWith`, `requires`, `produces`, and `consumes` without a central ontology.

Never broaden scopes, strip `noShare`, disclose restricted location, or put secrets in public manifests. Reading does not imply consent to write.

## 14–16. Writes, outcomes and errors

A write adapter can cause an external effect and needs stronger policy: proposal → policy → consent/mandate → adapter validation → machine safety → execution → outcome. Physical actions are never `SAFE_AUTO` by default. Never allow LLM → PLC coil write directly.

Outcomes distinguish `requested`, `sent`, `acknowledged`, `executed`, and `verified`. Claim verified success only with external evidence. Errors keep stable codes and causality; they are not success.

## 17–19. Offline, retry, dedupe and security

Offline adapters may queue bounded envelopes and retry idempotently. Preserve ID/revision/hash, chain, source refs, hops and `visitedAdapters` to prevent UTOPY → MQTT → UTOPY loops. Validate before signing, isolate secrets, rotate/revoke credentials, use least privilege, and separate read/write credentials.

## 20–22. Conformance, versioning and distribution

Use `conformance/v1` and `schemas/v1`. The reference CLI reads neutral JSON: `npm run conformance < conformance/v1/envelope-valid.json`. Other languages reproduce the same checks without Node. Compatibility is not endorsement.

An optional signed `utopy.adapter.manifest` declares adapter ID, name/version, protocol version, authority, translations, capabilities, requirements/platforms, docs/source refs and issue/expiry. It can announce `bridge.opcua`, `protocol.opcua.read`, or `device.discover`; `findBridgeFor` discovers it through ordinary capabilities, never a registry.

## 23. Examples

- ESP32 → temperature → MQTT → community adapter → LivingEnvelope → Node Emergence → GE. A future UTOPY Embedded C/C++ family may implement minimal identity/sign/capability/state/measurement/need/outcome; today small devices can use gateway mode with provenance.
- PLC → OPC-UA → third-party adapter → capability/state → Node Emergence → GE/MO/Mapa.
- WooCommerce → third-party adapter → product/order envelopes → Market; Market contains no WooCommerce code.
- payment request → future Bancard/PIX adapter → external system → verified payment outcome; manifests carry no payment secrets.
- PLC → OPC-UA adapter → UTOPY → MQTT adapter retains source refs, authority, chain and translation provenance.

## 24. Non-goals

Core does not ship every adapter, certify businesses, own third-party code, centralize extension schemas, create political governance, bypass industrial safety, or equate compatibility with trust.

