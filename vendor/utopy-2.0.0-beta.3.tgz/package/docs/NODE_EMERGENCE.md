# Node Emergence

Node Emergence turns verified LivingEnvelope evidence into a local deterministic `LivingNodeProjection`. Data remains truth; the projection is bounded, reconstructible understanding for discovery and reasoning. There is no global registry.

## Evidence and levels

An isolated measurement, image, unsigned offer, name, handle, IP or store ID cannot establish a node. Evidence needs stable cryptographic authority, persistent subject reference, verified source refs, meaningful capability/state/relationship, plus continuity or a valid manifest.

- `candidate`: insufficient and hidden from default `list()`.
- `emerging`: meaningful identity or continuity exists but is incomplete.
- `established`: manifest/adapter manifest with capability, or continuous identity plus meaningful evidence.

`confidence` measures emergence completeness only, never trust or reputation.

## Projection, identity and lifecycle

The projection includes authority-bound identity, optional public hints, capabilities with `DECLARED`, `OBSERVED`, or `VERIFIED_BY_OUTCOME` provenance, state, authorized territory, arbitrary relationships, source refs, timestamps, revision, level and status. It does not copy full DV payloads.

Manifestless IDs deterministically hash `authority + subjectRef`. A later signed manifest reconciles only under the same authority and explicit alias/subject evidence, or an unambiguous same-actor subject. Authorities are never merged because handles match. Prior IDs remain aliases.

Presence expiry makes state `offline` and status `dormant`; history remains. Revocation marks projections and rejects new evidence. Identical verified evidence in canonical order yields the same semantic projection.

## Security, privacy and loops

Public `observe()` validates hash and ES256 signature. Runtime calls it after Runtime verification and dedupe. Private/participant/noShare evidence, restricted territory and private capabilities are excluded from public projections. Internal `node.emerged`, `node.updated`, `node.dormant`, `node.reconciled`, and `node.revoked` events are not DVs and are ignored as evidence.

## API

`runtime.emergence` and `runtime.sdk.emergence` expose `observe`, `project`, `get`, `list`, `subscribe`, `resolveLivingNode`, `findNodesByCapability`, `getRelationships`, `explainEmergence`, and `findBridgeFor`. Explanations are evidence traces, not hidden model reasoning.

## Emergence through adapters

An adapter translates external observations while preserving `observedBy`, `attestedBy`, `translatedBy`, source refs, chain and authority boundaries. Evidence passes normal verification; Node Emergence projects it. The adapter does not manually create a node or own every translated device.

PLC → OPC-UA → third-party adapter → identity/capability/state envelopes → Node Emergence → LivingNodeProjection. “Gateway X observed Device Y” is not “Gateway X is Device Y.”

Market, MO, GE, MT, FEDA, Discovery and SymbioticMind can consume local projections without becoming authority. Micelio transports only. The compact evidence index is bounded and reconstructible; it is not another factual store.

