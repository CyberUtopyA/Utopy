# Runtime identity trust projection

`utopy/identity/server` exposes the existing ES256 projection and the concrete
`createRuntimeIdentityTrustAdapter(runtime)`, `verifyRuntimeWalletEvidence`,
`loadConfiguredProjectionSigner` and `provisionProjectionKey` functions.
These are Node ESM modules; no identity service or authentication database is added.

## Real evidence without a replacement store

The adapter reads the deployed Runtime's existing `list()` / EnvelopeStore,
`authorities`, `discovery.listKnownNodes()` and `symbioticMind.mandates.list()`.
It never reads browser storage or private wallet/recovery exports.

The existing MO integration retains public wallet proofs in
`payload: {schema: "mo.dv/1", dv, transportMode}`. The adapter verifies the original
`dv.meta.ownership` contract `utopy.owner/2`, including:

- DID fingerprint of the initial public root, using the existing wallet algorithm;
- contiguous root history and both signatures of each `utopy.root.rotation/1`;
- root-signed `utopy.device.certificate/1`, exact device/key/public-key association;
- root-signed `utopy.device.revocation/1` and issuer validity at issuance;
- original DV signature, actor association and signed expiry mapped by MO.

Rotated roots remain revoked. Device revocations accumulate across available signed
evidence. Roots without contractual expiry are bounded by the short-lived signed
projection; expired evidence never supplies live root authorization.

Native `utopy.node.manifest`, `mandate.grant` and `mandate.revoke` envelopes retain
the existing canonical content hash and ES256 signature verification. Authority
must be accepted by AuthorityRegistry and match the public key in actual Runtime
identity or Discovery. A trusted key ID alone is insufficient.

Node access requires a current Discovery manifest and matching live MandateBook
grant. The signed grant must explicitly bind `nodeId`, `clientId`, `roles` and
`allowedActions`. It must bind the subject DID: `actor` is that DID, or `ownerDid`
is that DID alongside the existing actor reference. Matching an actor string alone
cannot grant another DID's node access. Signed revocations override grants even
before MandateBook processes them. Expiry, forbidden actions, absent live grants
and changed authority state deny access. Wildcards or delegated constraints that
the snapshot cannot represent are rejected rather than widened.

**Existing contract limitation:** native `Mandate` defines delegation actions,
limits and participants, but not DID/client/node/role associations. A generic
native mandate therefore projects no node authorization. If actual deployed signed
relations lack these associations, this adapter cannot fabricate them. A native
`UtopyIdentity` containing only actorId and an ownership key is not a wallet DID
and root chain. Profile fields are not synthesized from node names or identities.

The existing MO observer uses NullEnvelopeStore. An empty observer cannot emit
trust. The server host must expose its existing complete evidence-backed Runtime
and store, including rotations and revocations. No second store is created.

## Signer and public verifier provisioning

Configure:

```text
UTOPY_IDENTITY_PROJECTION_KEY_ID=<stable emitter key ID>
UTOPY_IDENTITY_PROJECTION_SIGNER_SECRET_REF=env:UTOPY_TRUST_SIGNER_PEM
UTOPY_IDENTITY_PROJECTION_PUBLIC_KEY=<absolute public SPKI PEM path>
```

Inject `UTOPY_TRUST_SIGNER_PEM` through deployment secrets. Alternatively use
`file:<absolute private PKCS8 PEM path outside this repository>` or an existing
secret-manager reference resolved by the host's `resolveSecret(ref)`. The loader
requires P-256 and validates that the private key matches the separately provisioned
public verifier. Secret material and private references are never printed. POSIX
secret files must deny group/other access. On Windows, restrict the secret directory
ACL to the service account; environment/secret-manager injection avoids file custody.

For one-time generation, provision secure directories and select a `file:` secret
reference plus the public PEM path and key ID. Run
`npm run identity:trust:key:provision`. It exclusively creates the private key outside
the repo and exports the public SPKI PEM; existing keys are never overwritten.
If interrupted between writes, recover the public PEM from the same private key;
do not regenerate or silently rotate it. Consumers receive only the public PEM
and key ID through the existing trusted deployment channel. A snapshot never
establishes trust in its own signer.

## Generate and sync from the deployed Runtime

Configure:

```text
UTOPY_IDENTITY_RUNTIME_MODULE=<absolute deployed host ES module>
UTOPY_IDENTITY_TRUST_FILE=<absolute signed snapshot/cache path outside docroot>
UTOPY_IDENTITY_PROJECTION_TTL_MS=300000
```

The server-owned module exports the actual `runtime` or `getRuntime()` and
`nextIdentityTrustRevision()`. The latter allocates a persistent monotonic revision
in the host's existing state; a process-local counter or constant is insufficient.
It may also export `resolveSecret(ref)`. Offline `getRuntime()` can throw an error
with `code: "RUNTIME_OFFLINE"`; missing relations, invalid proof and configuration
errors are not transport outages.

Run `npm run identity:trust:sync`. This built-in mode uses the concrete adapter,
signs the same `utopy.identity.trust/1` body, and verifies the external public pin
before atomic refresh. No fixture or permissive relationship verifier is used.

Consumers can instead set `UTOPY_IDENTITY_PROJECTION_SOURCE` to the signed artifact's
existing local path or HTTPS location. They require only public PEM, key ID and
trust file, not a signing secret. The existing server-owned
`UTOPY_IDENTITY_TRUST_SOURCE_MODULE` loader remains compatible. Configure exactly
one of the three source modes. No mandatory Identity API is introduced.

Sync retains locking and same-directory temp → fsync → verify → atomic replace.
It rejects revision/time rollback and resurrection of previously revoked roots,
devices and mandates. A signed expired snapshot remains a revision high-water mark.
Offline fallback accepts only an unexpired valid snapshot and never extends TTL.
Complete source history and the host's durable revision are required across cache
loss. Never manually edit the trust file. Remove a stale lock only after confirming
its writer is no longer running.

## Validation and deployment boundary

`npm run test:identity-trust` exercises the existing compiled UtopyRuntime,
Discovery, AuthorityRegistry and MandateBook with ephemeral cryptographic evidence.
Test doubles are confined to unit tests. Server modules require no build.

No production signing key, deployed Runtime module, durable revision allocator or
signed node/client/DID/role grant was supplied in this workspace. The code fails
closed until those real deployment inputs are configured; local test success does
not establish that a production identity has been authorized.
