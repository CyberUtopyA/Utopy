# Living administrative interface

`utopy/living-space` exports `projectLivingInterface`, `interfaceCompositionInput` and the serializable `utopy.living-interface/1` projection. This is an administrative presentation contract, not a second planner, permission engine, store, identity, or executor.

The host supplies the currently verified actor/node context, a `LocalCapabilitySandbox` containing actual installed handlers, static allowlisted presentation metadata and an `authorize` callback backed by its real Authority/delegation path. Network declarations and role names must never be treated as installed handlers or proof of permission. Invocation of the projector does not execute handlers or authenticate the host.

The projector reuses `RuleReasoner` and `projectReasoningForm`. It accepts only a private intent scoped to the current actor/node. It selects only installed, authorized declarations; rejects ambiguous versions and components outside the fixed allowlist; retains schema validation and known falsey values; leaves unknown tasks unresolved. Voice is a host adapter producing the same text intent, not a dependency on FEDA, an LLM or a central service.

`interfaceCompositionInput` builds the **existing** `CompositionInput`. Hosts use the existing `LivingCompositionSDK` for signing/revision and `LivingCompositionEngine` for simulation/activation/execution. A UI preview, checked box, saved proposal or valid form is not execution authority. Handlers must independently recheck permission, revocation and current data at execution time. Previously serialized projections are untrusted input, not authorization tokens.

The fixed components are semantic slots (catalog, diagnosis, quote, agenda, charge, orders, progress, evidence, outcome, form). A `charge` slot can present a read-only charge query; it does not imply payment initiation. No HTML, downloaded scripts, module URLs or generated code are loaded. Hosts render labels as text, not HTML.

Host responsibilities: private actor/node storage, authenticated transport, atomic stock/booking transactions, capability provenance, consent evidence, mandate limits, conflict detection and true delivery/payment outcomes. The projection performs no persistence/synchronization and makes no offline execution claim for network-required capabilities. Offline rendering and local handlers remain usable with verified local permissions. Templates and business names provide suggestions only and never install capabilities or widen grants.

Example consumer: MS Market administrative `/n/:slug/gestionar`. Public feed, storefront, buyer navigation and checkout do not need this module. Other node shells can consume the same export without Market.
