# Integración progresiva

## MO

Publica `living.design`, `material.need`, `work.request`, `liquidity.need`; conserva `designId/versionId/workId/threadId/chainId` en payload y/o envelope.

## MS Market / Falcon

Observan productos/ofertas/perfiles y usan el mismo runtime para respuestas. Market es una interfaz de mercado, no coordinador obligatorio.

## Mapa Circular

Consume capabilities públicas, territorio aproximado y necesidades; no debe revelar datos privados de relaciones.

## Nodo comercial ligero

Un perfil puede comenzar con identidad + capabilities + inbox/outbox. Cuando crece, conserva la misma identidad y añade handlers.

## Seed existente

Integrar mediante `SeedWebSocketTransport`. Gradualmente agregar conexión directa entre peers y mantener Seed como fallback/store-forward.
