import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { syncIdentityTrust } from './identity-trust.mjs';
import { createRuntimeProjectionLoader } from './identity-runtime-source.mjs';

try {
  const path = process.env.UTOPY_IDENTITY_TRUST_FILE;
  const adapterPath = process.env.UTOPY_IDENTITY_TRUST_SOURCE_MODULE;
  const projectionSource = process.env.UTOPY_IDENTITY_PROJECTION_SOURCE;
  const publicKeyPath = process.env.UTOPY_IDENTITY_PROJECTION_PUBLIC_KEY;
  const keyId = process.env.UTOPY_IDENTITY_PROJECTION_KEY_ID;
  const runtimeModule = process.env.UTOPY_IDENTITY_RUNTIME_MODULE;
  if (![path, publicKeyPath, keyId].every(Boolean) || (!runtimeModule && !adapterPath && !projectionSource)) throw Error('identity-trust-config-required');
  if ([runtimeModule, adapterPath, projectionSource].filter(Boolean).length !== 1) throw Error('identity-trust-source-ambiguous');
  // A server-owned module, never a request parameter. No mandatory network endpoint.
  const loadProjection = runtimeModule ? await createRuntimeProjectionLoader() : adapterPath ? (await import(pathToFileURL(resolve(adapterPath)).href)).loadProjection : async () => {
    let raw;
    if (projectionSource.startsWith('https://')) {
      let response;
      try { response = await fetch(projectionSource, { signal: AbortSignal.timeout(15000), redirect: 'error' }); }
      catch { throw Object.assign(Error('runtime-offline'), { code: 'RUNTIME_OFFLINE' }); }
      if (response.status === 503 || response.status === 502 || response.status === 504) throw Object.assign(Error('runtime-offline'), { code: 'RUNTIME_OFFLINE' });
      if (!response.ok) throw Error('projection-source-rejected');
      raw = await response.text();
    } else {
      if (/^[a-z]+:\/\//i.test(projectionSource)) throw Error('projection-source-requires-https');
      try { raw = await readFile(resolve(projectionSource), 'utf8'); }
      catch (e) { if (e.code === 'ENOENT') e.code = 'RUNTIME_OFFLINE'; throw e; }
    }
    if (Buffer.byteLength(raw) > 6 * 1024 * 1024) throw Error('projection-too-large');
    return JSON.parse(raw);
  };
  const publicKey = await readFile(publicKeyPath, 'utf8');
  const result = await syncIdentityTrust({ path: resolve(path), load: loadProjection, trust: { keyId, publicKey } });
  console.log(JSON.stringify(result));
} catch (error) {
  console.error(JSON.stringify({ ok: false, reason: error.code ?? error.message })); process.exitCode = 1;
}
