import { createHash, createPublicKey, verify } from 'node:crypto';

const fail = message => { throw Error(message); };
const canonical = v => v && typeof v === 'object' ? Array.isArray(v) ? '[' + v.map(canonical).join(',') + ']' : '{' + Object.keys(v).filter(k => v[k] !== undefined).sort().map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}' : JSON.stringify(v);
const hash = value => createHash('sha256').update(canonical(value)).digest('base64url');
const without = (value, field) => Object.fromEntries(Object.entries(value).filter(([key]) => key !== field));
const publicPart = jwk => {
  if (!jwk || jwk.kty !== 'EC' || jwk.crv !== 'P-256' || 'd' in jwk) fail('runtime-private-or-invalid-key');
  createPublicKey({ key: jwk, format: 'jwk' });
  return { kty: jwk.kty, crv: jwk.crv, x: jwk.x, y: jwk.y, key_ops: ['verify'], ext: true };
};
const sameKey = (a, b) => canonical(publicPart(a)) === canonical(publicPart(b));
const signature = (jwk, value, raw) => {
  if (typeof raw !== 'string' || !/^[A-Za-z0-9_-]+$/.test(raw)) return false;
  const bytes = Buffer.from(raw, 'base64url');
  return bytes.length === 64 && bytes.toString('base64url') === raw && verify('sha256', Buffer.from(canonical(value)),
    { key: createPublicKey({ key: publicPart(jwk), format: 'jwk' }), dsaEncoding: 'ieee-p1363' }, bytes);
};
const date = value => { const ms = typeof value === 'string' ? Date.parse(value) : NaN; if (!Number.isFinite(ms)) fail('runtime-relation-date'); return ms; };
const texts = value => Array.isArray(value) && value.every(v => typeof v === 'string' && v.length > 0);

/** Verifies the existing utopy.owner/2 contract retained by mo.dv/1.
 * This consumes public signed evidence only, never the browser wallet or recovery data. */
export function verifyRuntimeWalletEvidence(envelope, now = Date.now()) {
  const dv = envelope.payload?.dv; const owner = dv?.meta?.ownership;
  if (envelope.payload?.schema !== 'mo.dv/1' || owner?.protocol !== 'utopy.owner/2' || !Array.isArray(owner.rootHistory)
    || !owner.rootHistory.length || !Array.isArray(owner.revocations)) fail('runtime-wallet-evidence-required');
  const roots = owner.rootHistory; const first = roots[0];
  if (first.sequence !== 1 || owner.ownerDid !== `did:utopy:${hash(publicPart(first.publicKeyJwk)).slice(0, 40)}`) fail('runtime-did-root-binding');
  const ids = new Set();
  for (let i = 0; i < roots.length; i++) {
    const root = roots[i]; publicPart(root.publicKeyJwk);
    if (!root.keyId || ids.has(root.keyId) || date(root.activeFrom) > now) fail('runtime-root-history');
    ids.add(root.keyId);
    if (!i) continue;
    const previous = roots[i - 1];
    const transition = { protocol: 'utopy.root.rotation/1', sequence: root.sequence, keyId: root.keyId,
      publicKeyJwk: root.publicKeyJwk, activeFrom: root.activeFrom, previousKeyId: root.previousKeyId || null };
    if (root.sequence !== previous.sequence + 1 || root.previousKeyId !== previous.keyId || date(root.activeFrom) < date(previous.activeFrom)
      || !signature(previous.publicKeyJwk, transition, root.transition?.previousSignature)
      || !signature(root.publicKeyJwk, transition, root.transition?.nextSignature)) fail('runtime-root-rotation');
  }
  const cert = owner.deviceCertificate; const root = roots.find(k => k.keyId === cert?.rootKeyId);
  const successor = root && roots.find(k => k.sequence === root.sequence + 1);
  const signedAt = date(owner.signedAt);
  if (!root || cert.protocol !== 'utopy.device.certificate/1' || cert.ownerDid !== owner.ownerDid || cert.deviceId !== owner.deviceId
    || cert.keyId !== owner.keyId || !cert.permissions?.includes('sign') || !sameKey(cert.publicKeyJwk, owner.publicKeyJwk)
    || date(cert.issuedAt) > signedAt || signedAt > now || date(root.activeFrom) > date(cert.issuedAt)
    || (successor && date(cert.issuedAt) >= date(successor.activeFrom))
    || !signature(root.publicKeyJwk, without(cert, 'signature'), cert.signature)) fail('runtime-device-certificate');
  for (const revocation of owner.revocations) {
    const issuer = roots.find(k => k.keyId === revocation.rootKeyId);
    const nextIssuer = issuer && roots.find(k => k.sequence === issuer.sequence + 1);
    if (!issuer || revocation.protocol !== 'utopy.device.revocation/1' || revocation.ownerDid !== owner.ownerDid
      || !revocation.deviceId || date(revocation.revokedAt) > now
      || date(revocation.revokedAt) < date(issuer.activeFrom) || (nextIssuer && date(revocation.revokedAt) >= date(nextIssuer.activeFrom))
      || !signature(issuer.publicKeyJwk, without(revocation, 'signature'), revocation.signature)) fail('runtime-device-revocation');
    if (revocation.deviceId === cert.deviceId && date(revocation.revokedAt) <= signedAt) fail('runtime-revoked-signing-device');
  }
  const unsigned = structuredClone(dv); delete unsigned.meta.ownership.signature;
  if (owner.signature?.alg !== 'ES256' || !signature(cert.publicKeyJwk, unsigned, owner.signature.value)) fail('runtime-owned-dv-signature');
  if (envelope.id !== dv.id || envelope.kind !== dv.kind || envelope.authority !== owner.ownerDid) fail('runtime-legacy-binding');
  const meta = dv.meta ?? {};
  const created = meta.ts ?? dv.ts ?? dv.at;
  const createdMs = created == null ? 0 : typeof created === 'number' || /^\d+$/.test(String(created)) ? Number(created) : date(created);
  const ttl = Number(meta.ttl_ms ?? meta.ttlMs);
  const expectedExpiry = meta.expiresAt ? new Date(date(meta.expiresAt)).toISOString()
    : Number.isFinite(ttl) && ttl > 0 ? new Date(createdMs + ttl).toISOString() : undefined;
  if (envelope.expiresAt !== expectedExpiry || envelope.createdAt !== new Date(createdMs).toISOString()) fail('runtime-legacy-expiry-binding');
  const actorId = owner.controllerActorId || dv.attrs?.actorId;
  if (!actorId || actorId !== envelope.sourceActorId || (dv.attrs?.actorId && dv.attrs.actorId !== actorId)) fail('runtime-actor-binding');
  return { did: owner.ownerDid, actorId, owner, dv };
}

/** Read-only adapter over the existing Runtime store, AuthorityRegistry,
 * NodeDiscovery and MandateBook. No identities, roles or client bindings are synthesized. */
export function createRuntimeIdentityTrustAdapter(runtime) {
  if (!runtime?.list || !runtime.authorities?.accepts || !runtime.discovery?.listKnownNodes || !runtime.symbioticMind?.mandates?.list) fail('runtime-instance-required');
  let resolved;
  let authorizationState;
  const state = () => canonical({ nodes: runtime.discovery.listKnownNodes(), mandates: runtime.symbioticMind.mandates.list() });
  const accepts = e => (e.payload?.schema === 'mo.dv/1' && e.payload.dv?.meta?.ownership?.protocol === 'utopy.owner/2')
    || ['utopy.node.manifest', 'mandate.grant', 'mandate.revoke'].includes(e.kind);
  const trust = (authority, keyId, jwk) => {
    if (!runtime.authorities.accepts(authority, keyId)) return false;
    const identity = runtime.identity;
    if (authority === (identity.nodeId ?? identity.actorId) && keyId === identity.keyId && sameKey(jwk, identity.publicKeyJwk)) return true;
    return runtime.discovery.listKnownNodes().some(n => n.manifest.authority === authority && n.authorityKeyId === keyId && sameKey(jwk, n.authorityPublicKeyJwk));
  };
  const resolve = async (evidence, now) => {
    authorizationState = state();
    const wallets = new Map(); const records = new Map();
    for (const e of evidence.filter(e => e.payload?.schema === 'mo.dv/1')) {
      const wallet = verifyRuntimeWalletEvidence(e, now); const old = wallets.get(wallet.did);
      if (old && (old.actorId !== wallet.actorId || old.owner.rootHistory.some((r, i) => wallet.owner.rootHistory[i]
        && canonical(r) !== canonical(wallet.owner.rootHistory[i])))) fail('runtime-conflicting-wallet-history');
      if (!old || wallet.owner.rootHistory.length > old.owner.rootHistory.length
        || (wallet.owner.rootHistory.length === old.owner.rootHistory.length && date(wallet.owner.signedAt) > date(old.owner.signedAt))) wallets.set(wallet.did, { ...wallet, envelope: e });
      let entry = records.get(wallet.did);
      if (!entry) {
        entry = { actorId: wallet.actorId, status: 'active', roots: {}, revokedDeviceIds: [], authorizedNodes: [], sourceRefs: [], name: '', avatar: '', profileUrl: '' };
        records.set(wallet.did, entry);
      }
      entry.sourceRefs.push(e.id);
      for (const root of wallet.owner.rootHistory) {
        const refs = entry.roots[root.keyId]?.sourceRefs ?? [];
        entry.roots[root.keyId] = { status: 'active', publicKeyJwk: publicPart(root.publicKeyJwk),
          expiresAt: new Date(now + 3_600_000).toISOString(), sourceRefs: [...new Set([...refs, e.id])] };
      }
      entry.revokedDeviceIds = [...new Set([...entry.revokedDeviceIds, ...wallet.owner.revocations.map(r => r.deviceId)])];
    }
    if (!records.size) fail('runtime-real-wallet-relations-missing');
    for (const [did, wallet] of wallets) {
      const entry = records.get(did); const active = wallet.owner.rootHistory.at(-1).keyId;
      entry.roots[active].expiresAt = wallet.envelope.expiresAt ?? new Date(now + 3_600_000).toISOString();
      for (const [keyId, key] of Object.entries(entry.roots)) if (keyId !== active) key.status = 'revoked';
    }
    const nodes = runtime.discovery.listKnownNodes(); const mandates = runtime.symbioticMind.mandates.list();
    for (const e of evidence.filter(e => e.kind === 'mandate.grant' && e.payload?.schema !== 'mo.dv/1')) {
      const m = e.payload;
      const identity = [...records].find(([did, r]) => m.actor === did || (r.actorId === m.actor && m.ownerDid === did));
      const entry = identity?.[1];
      if (!entry && (m.nodeId || m.clientId || m.roles) && [...records.values()].some(r => r.actorId === m.actor)) fail('runtime-mandate-did-binding');
      if (!entry) continue;
      const current = mandates.find(value => value.mandateId === m.mandateId);
      // Native Mandate does not imply node access, roles or Studio client association.
      // A live grant must carry these exact signed associations to be projected.
      if (!m.nodeId && !m.clientId && !m.roles) continue;
      if (!m.nodeId || !m.clientId || !texts(m.roles) || !texts(m.allowedActions) || !texts(m.forbiddenActions)
        || m.actor !== e.sourceActorId || !m.goal) fail('runtime-node-mandate-binding');
      const node = nodes.find(n => n.manifest.nodeId === m.nodeId);
      if (!node || node.manifest.authority !== e.authority || !trust(e.authority, e.ownership.keyId, e.ownership.publicKeyJwk)) fail('runtime-node-authority');
      const manifest = evidence.find(v => v.kind === 'utopy.node.manifest' && v.payload?.schema !== 'mo.dv/1'
        && v.payload.nodeId === m.nodeId && v.payload.revision === node.manifest.revision
        && canonical(without(node.manifest, 'signature')) === canonical(v.payload));
      if (!manifest || date(node.manifest.issuedAt) > now) fail('runtime-current-manifest-missing');
      const revoked = evidence.some(v => v.kind === 'mandate.revoke' && v.payload?.mandateId === m.mandateId
        && v.authority === e.authority && v.sourceActorId === m.actor);
      const expiry = Math.min(date(m.expiresAt), e.expiresAt ? date(e.expiresAt) : Infinity,
        manifest.expiresAt ? date(manifest.expiresAt) : Infinity, node.manifest.expiresAt ? date(node.manifest.expiresAt) : now + 3_600_000);
      const hasActiveRoot = Object.values(entry.roots).some(k => k.status === 'active' && date(k.expiresAt) > now);
      const status = !hasActiveRoot || revoked || !current || canonical(current) !== canonical(m) || expiry <= now ? 'revoked' : 'active';
      // Constrained delegated mandates cannot be widened to unrestricted Studio permissions.
      if (status === 'active' && (m.limits || m.budget || m.territory || m.participants?.length || m.privacyPolicy)) fail('runtime-constrained-mandate-not-projectable');
      const actions = m.allowedActions.filter(action => !m.forbiddenActions.some(rule => rule === '*' || rule === action || (rule.endsWith('.*') && action.startsWith(rule.slice(0, -1)))));
      if (actions.some(action => action.includes('*'))) fail('runtime-wildcard-mandate-not-projectable');
      entry.authorizedNodes.push({ nodeId: m.nodeId, clientId: m.clientId, mandateId: m.mandateId, authority: e.authority,
        status, expiresAt: new Date(expiry).toISOString(), roles: status === 'active' ? m.roles : [], allowedActions: status === 'active' ? actions : [],
        sourceRefs: [e.id, manifest.id, ...evidence.filter(v => v.kind === 'mandate.revoke' && v.payload?.mandateId === m.mandateId && v.authority === e.authority && v.sourceActorId === m.actor).map(v => v.id)], name: node.manifest.name } );
    }
    const actors = [...records.values()].map(r => r.actorId);
    if (new Set(actors).size !== actors.length) fail('runtime-conflicting-actor-did');
    resolved = [...records].map(([did, record]) => ({ did, record }));
    return structuredClone(resolved);
  };
  return { accepts, trust, verifySource: (e, now) => { verifyRuntimeWalletEvidence(e, now); return true; }, resolve,
    // Expired sources remain historical revocation/rotation evidence, never live grants.
    historicalSource: (e, now) => !!e.expiresAt && date(e.expiresAt) <= now,
    verify: ({ did, record, evidence }) => state() === authorizationState
      && evidence.filter(e => e.payload?.schema !== 'mo.dv/1').every(e => trust(e.authority, e.ownership.keyId, e.ownership.publicKeyJwk))
      && !!resolved?.some(r => r.did === did && canonical(r.record) === canonical(record)) };
}
