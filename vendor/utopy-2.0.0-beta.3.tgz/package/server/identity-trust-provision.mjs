import { provisionProjectionKey } from './identity-trust-signer.mjs';
try { console.log(JSON.stringify(await provisionProjectionKey())); }
catch (error) { console.error(JSON.stringify({ ok: false, reason: error.code ?? error.message })); process.exitCode = 1; }
