import { createPublicKey, createHash, sign, verify, randomUUID } from 'node:crypto';
import { readFile, open, rename, unlink } from 'node:fs/promises';
import { dirname, basename, join } from 'node:path';

export const TRUST_PROTOCOL = 'utopy.identity.trust/1';
export { createRuntimeIdentityTrustAdapter, verifyRuntimeWalletEvidence } from './identity-runtime-adapter.mjs';
export { loadConfiguredProjectionSigner, provisionProjectionKey } from './identity-trust-signer.mjs';
const MAX_BYTES = 4 * 1024 * 1024;
const fail = (message) => { throw new Error(message); };
const validDate = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value));
const text = (v) => typeof v === 'string' && v.length > 0;
const refs = (v) => Array.isArray(v) && v.length > 0 && v.every(text);
const strings = (v) => Array.isArray(v) && v.every(text);
const canonical = (v) => v && typeof v === 'object' ? Array.isArray(v) ? '[' + v.map(canonical).join(',') + ']' : '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}' : JSON.stringify(v);
const b64 = (value) => {
  if (!text(value) || !/^[A-Za-z0-9_-]+$/.test(value)) fail('trust-encoding');
  const bytes = Buffer.from(value, 'base64url');
  if (bytes.toString('base64url') !== value) fail('trust-encoding');
  return bytes;
};
const publicJwk = (jwk) => {
  if (!jwk || jwk.kty !== 'EC' || jwk.crv !== 'P-256' || 'd' in jwk || b64(jwk.x).length !== 32 || b64(jwk.y).length !== 32) fail('trust-public-key');
  createPublicKey({ key: jwk, format: 'jwk' });
  return { kty: 'EC', crv: 'P-256', x: jwk.x, y: jwk.y };
};
const safeUrl = (value) => { try { const u = new URL(value); return u.protocol === 'https:' && !u.username && !u.password ? value : ''; } catch { return ''; } };

/** Whitelisted local evidence: no source payloads, private keys or income/billing data. */
function minimalRecord(record) {
  if (!text(record.actorId) || !['active', 'revoked'].includes(record.status) || !refs(record.sourceRefs)
    || !record.roots || !strings(record.revokedDeviceIds) || !Array.isArray(record.authorizedNodes)) fail('trust-record');
  const roots = Object.fromEntries(Object.entries(record.roots).map(([keyId, key]) => {
    if (!text(keyId) || !['active', 'revoked'].includes(key.status) || !validDate(key.expiresAt) || !refs(key.sourceRefs)) fail('trust-root');
    return [keyId, { status: key.status, publicKeyJwk: publicJwk(key.publicKeyJwk), expiresAt: key.expiresAt, sourceRefs: key.sourceRefs }];
  }));
  const authorizedNodes = record.authorizedNodes.map(node => {
    if (!text(node.nodeId) || !text(node.clientId) || !text(node.mandateId) || !text(node.authority)
      || !['active', 'revoked'].includes(node.status) || !validDate(node.expiresAt) || !strings(node.roles) || !strings(node.allowedActions) || !refs(node.sourceRefs)) fail('trust-mandate');
    return { nodeId: node.nodeId, clientId: node.clientId, mandateId: node.mandateId, authority: node.authority,
      status: node.status, expiresAt: node.expiresAt, roles: node.roles, allowedActions: node.allowedActions, sourceRefs: node.sourceRefs,
      name: typeof node.name === 'string' ? node.name : '', avatar: safeUrl(node.avatar) };
  });
  return { actorId: record.actorId, status: record.status, roots, revokedDeviceIds: record.revokedDeviceIds,
    authorizedNodes, sourceRefs: record.sourceRefs, name: typeof record.name === 'string' ? record.name : '',
    avatar: safeUrl(record.avatar), profileUrl: safeUrl(record.profileUrl) };
}

/** The adapter resolves current wallet roots/rotations and node mandates from Runtime
 * evidence, and verifies authority/consent using the existing wallet contracts.
 * No browser storage, arbitrary JSON identities, or self-declared roles are inputs. */
export async function projectIdentityTrust({ runtime, adapter, signer, revision, audience = 'studio.utopy.space', ttlMs = 300_000, now = Date.now() }) {
  if (!Number.isSafeInteger(revision) || revision < 1 || ttlMs <= 0 || ttlMs > 3_600_000) fail('trust-projection-limits');
  const evidence = await runtime.list(adapter.accepts);
  for (const e of evidence) {
    // Legacy MO envelopes retain the original signed DV rather than an outer signature.
    if (adapter.verifySource && e.payload?.schema === 'mo.dv/1') {
      if (await adapter.verifySource(e, now) !== true) fail('trust-source-signature');
      if (e.expiresAt && !adapter.historicalSource?.(e, now)) ttlMs = Math.min(ttlMs, Date.parse(e.expiresAt) - now);
      continue;
    }
    if (!e.ownership || e.ownership.alg !== 'ES256' || !await adapter.trust(e.authority, e.ownership.keyId, e.ownership.publicKeyJwk)) fail('trust-source-authority');
    const unsigned = structuredClone(e); delete unsigned.ownership; unsigned.hop = 0; unsigned.visitedNodeIds = []; delete unsigned.routeTrace;
    const hashInput = { ...unsigned, contentHash: '' };
    if (createHash('sha256').update(canonical(hashInput)).digest('base64url') !== e.contentHash
      || !verify('sha256', Buffer.from(canonical(unsigned)), { key: createPublicKey({ key: publicJwk(e.ownership.publicKeyJwk), format: 'jwk' }), dsaEncoding: 'ieee-p1363' }, b64(e.ownership.signature))) fail('trust-source-signature');
    if (e.expiresAt && !adapter.historicalSource?.(e, now)) ttlMs = Math.min(ttlMs, Date.parse(e.expiresAt) - now);
  }
  if (!Number.isFinite(ttlMs) || ttlMs <= 0) fail('trust-source-expired');
  const records = await adapter.resolve(evidence, now);
  const identities = Object.create(null);
  for (const { did, record } of records) {
    if (!text(did) || !did.startsWith('did:') || Object.hasOwn(identities, did)) fail('trust-did');
    // Must validate complete authority chains, current revocations and node/client binding.
    if (await adapter.verify({ did, record, evidence, now }) !== true) fail('trust-unverified-relations');
    identities[did] = minimalRecord(record);
    const available = new Set(evidence.map(e => e.id));
    const allRefs = [...record.sourceRefs, ...Object.values(record.roots).flatMap(k => k.sourceRefs), ...record.authorizedNodes.flatMap(n => n.sourceRefs)];
    if (allRefs.some(ref => !available.has(ref))) fail('trust-source-missing');
  }
  const body = { protocol: TRUST_PROTOCOL, audience, issuedAt: new Date(now).toISOString(), expiresAt: new Date(now + ttlMs).toISOString(), revision,
    sourceRefs: [...new Set(Object.values(identities).flatMap(r => [...r.sourceRefs, ...Object.values(r.roots).flatMap(k => k.sourceRefs), ...r.authorizedNodes.flatMap(n => n.sourceRefs)]))].sort(), identities };
  const bytes = Buffer.from(canonical(body), 'utf8');
  const signature = await signer.sign(bytes);
  const snapshot = { protocol: TRUST_PROTOCOL, payload: bytes.toString('base64url'), proof: { alg: 'ES256', keyId: signer.keyId, signature: Buffer.from(signature).toString('base64url') } };
  // Verify before making any projection available to a consumer.
  verifyIdentityTrust(snapshot, { keyId: signer.keyId, publicKey: signer.publicKey, audience, now });
  return snapshot;
}

export function createProjectionSigner(keyId, privateKey) {
  const publicKey = createPublicKey(privateKey);
  if (publicKey.asymmetricKeyType !== 'ec' || publicKey.asymmetricKeyDetails?.namedCurve !== 'prime256v1') fail('trust-signer-curve');
  return { keyId, publicKey, sign: (bytes) => sign('sha256', bytes, { key: privateKey, dsaEncoding: 'ieee-p1363' }) };
}

export function verifyIdentityTrust(snapshot, { keyId, publicKey, audience = 'studio.utopy.space', now = Date.now() }) {
  if (!snapshot || snapshot.protocol !== TRUST_PROTOCOL || snapshot.proof?.alg !== 'ES256' || snapshot.proof.keyId !== keyId) fail('trust-proof');
  const bytes = b64(snapshot.payload); const signature = b64(snapshot.proof.signature);
  if (bytes.length > MAX_BYTES || signature.length !== 64 || !verify('sha256', bytes, { key: publicKey, dsaEncoding: 'ieee-p1363' }, signature)) fail('trust-signature');
  const body = JSON.parse(bytes.toString('utf8'));
  if (body.protocol !== TRUST_PROTOCOL || body.audience !== audience || !validDate(body.issuedAt) || !validDate(body.expiresAt)
    || Date.parse(body.issuedAt) > now || Date.parse(body.expiresAt) <= now || Date.parse(body.expiresAt) <= Date.parse(body.issuedAt)
    || Date.parse(body.expiresAt) - Date.parse(body.issuedAt) > 3_600_000 || !Number.isSafeInteger(body.revision) || body.revision < 1
    || !body.identities || Array.isArray(body.identities)) fail('trust-validity');
  for (const [did, record] of Object.entries(body.identities)) {
    if (!did.startsWith('did:') || !sameRecord(record, minimalRecord(record))) fail('trust-record-shape');
  }
  return body;
}
function sameRecord(a, b) { return canonical(a) === canonical(b); }

/** Single writer lock, same-directory temp, fsync, re-verification, atomic rename.
 * A failed refresh never overwrites or removes the last snapshot. */
export async function syncIdentityTrust({ path, load, trust }) {
  const lockPath = path + '.lock'; const lock = await open(lockPath, 'wx', 0o600);
  const temp = join(dirname(path), `.${basename(path)}.${randomUUID()}.tmp`);
  try {
    let previous;
    try { previous = JSON.parse(await readFile(path, 'utf8')); } catch (e) { if (e.code !== 'ENOENT' && !(e instanceof SyntaxError)) throw e; }
    let next;
    try { next = await load(); }
    catch (error) {
      // Offline is an explicit transport condition. Invalid evidence is never fallback.
      if (error.code !== 'RUNTIME_OFFLINE' || !previous) throw error;
      verifyIdentityTrust(previous, trust); return { updated: false, reason: 'valid-offline-cache' };
    }
    const body = verifyIdentityTrust(next, trust);
    if (previous) {
      // Even an expired, signed cache is an anti-rollback high-water mark.
      let old;
      try { const oldPayload = JSON.parse(b64(previous.payload).toString('utf8')); old = verifyIdentityTrust(previous, { ...trust, now: Date.parse(oldPayload.issuedAt) }); } catch { /* Corrupt cache is replaceable only by verified fresh evidence. */ }
      if (old && (body.revision < old.revision || (body.revision === old.revision && next.payload !== previous.payload) || body.issuedAt < old.issuedAt)) fail('trust-rollback');
      if (old) for (const [did, record] of Object.entries(body.identities)) {
        const known = old.identities[did]; if (!known) continue;
        if ((known.status === 'revoked' && record.status === 'active')
          || known.revokedDeviceIds.some(id => !record.revokedDeviceIds.includes(id))
          || Object.entries(known.roots).some(([id, key]) => key.status === 'revoked' && record.roots[id]?.status === 'active')
          || known.authorizedNodes.some(node => node.status === 'revoked' && record.authorizedNodes.some(n => n.mandateId === node.mandateId && n.authority === node.authority && n.status === 'active'))) fail('trust-revocation-rollback');
      }
    }
    const handle = await open(temp, 'wx', 0o600);
    try { await handle.writeFile(JSON.stringify(next)); await handle.sync(); } finally { await handle.close(); }
    verifyIdentityTrust(JSON.parse(await readFile(temp, 'utf8')), trust);
    await rename(temp, path);
    return { updated: true, revision: body.revision, expiresAt: body.expiresAt };
  } finally {
    await unlink(temp).catch(e => { if (e.code !== 'ENOENT') throw e; });
    await lock.close(); await unlink(lockPath);
  }
}
