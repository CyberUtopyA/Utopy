import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { projectIdentityTrust } from './identity-trust.mjs';
import { createRuntimeIdentityTrustAdapter } from './identity-runtime-adapter.mjs';
import { loadConfiguredProjectionSigner } from './identity-trust-signer.mjs';

/** Loads the deployed Runtime and its existing monotonic host revision, not a fixture. */
export async function createRuntimeProjectionLoader(env = process.env) {
  if (!env.UTOPY_IDENTITY_RUNTIME_MODULE) throw Error('identity-runtime-module-required');
  const host = await import(pathToFileURL(resolve(env.UTOPY_IDENTITY_RUNTIME_MODULE)).href);
  if (typeof host.nextIdentityTrustRevision !== 'function') throw Error('runtime-monotonic-revision-required');
  const signer = await loadConfiguredProjectionSigner(env, host.resolveSecret);
  return async () => {
    const runtime = typeof host.getRuntime === 'function' ? await host.getRuntime() : host.runtime;
    const adapter = createRuntimeIdentityTrustAdapter(runtime);
    return projectIdentityTrust({ runtime, adapter, signer, revision: await host.nextIdentityTrustRevision(),
      ttlMs: env.UTOPY_IDENTITY_PROJECTION_TTL_MS ? Number(env.UTOPY_IDENTITY_PROJECTION_TTL_MS) : 300_000 });
  };
}
