import { createPrivateKey, createPublicKey, generateKeyPairSync } from 'node:crypto';
import { readFile, open, stat, realpath } from 'node:fs/promises';
import { resolve, isAbsolute, relative, dirname, basename, join, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createProjectionSigner } from './identity-trust.mjs';

const repo = fileURLToPath(new URL('../', import.meta.url));
const fail = message => { throw Error(message); };
function secretFile(ref) {
  const path = ref.slice(5);
  if (!isAbsolute(path)) fail('projection-secret-file-must-be-absolute');
  const rel = relative(repo, resolve(path));
  if (rel !== '..' && !rel.startsWith('..' + sep) && !isAbsolute(rel)) fail('projection-secret-must-be-outside-repository');
  return resolve(path);
}
export async function loadConfiguredProjectionSigner(env = process.env, resolveSecret) {
  const ref = env.UTOPY_IDENTITY_PROJECTION_SIGNER_SECRET_REF;
  const keyId = env.UTOPY_IDENTITY_PROJECTION_KEY_ID;
  const publicPath = env.UTOPY_IDENTITY_PROJECTION_PUBLIC_KEY;
  if (!ref || !keyId || !publicPath) fail('projection-signer-config-required');
  let secret;
  if (ref.startsWith('env:')) {
    const name = ref.slice(4);
    if (!/^[A-Z][A-Z0-9_]*$/.test(name)) fail('projection-secret-env-reference');
    secret = env[name];
  } else if (ref.startsWith('file:')) {
    const path = secretFile('file:' + await realpath(secretFile(ref))); const info = await stat(path);
    if (!info.isFile() || (process.platform !== 'win32' && (info.mode & 0o077))) fail('projection-secret-file-permissions');
    secret = await readFile(path);
  } else if (resolveSecret) {
    try { secret = await resolveSecret(ref); } catch { fail('projection-secret-unavailable'); }
  }
  else fail('projection-secret-resolver-required');
  if (!secret) fail('projection-signing-secret-missing');
  let signer;
  // OpenSSL errors can include host details; never print secret material or references.
  try { signer = createProjectionSigner(keyId, createPrivateKey(secret)); } catch { fail('projection-signing-secret-invalid'); }
  const pinned = createPublicKey(await readFile(resolve(publicPath)));
  if (!pinned.export({ type: 'spki', format: 'der' }).equals(signer.publicKey.export({ type: 'spki', format: 'der' }))) fail('projection-signer-verifier-mismatch');
  return signer;
}

/** Explicit one-time provisioning to operator-selected paths; never overwrites keys. */
export async function provisionProjectionKey(env = process.env) {
  const ref = env.UTOPY_IDENTITY_PROJECTION_SIGNER_SECRET_REF;
  const publicPath = env.UTOPY_IDENTITY_PROJECTION_PUBLIC_KEY;
  if (!ref?.startsWith('file:') || !publicPath || !env.UTOPY_IDENTITY_PROJECTION_KEY_ID) fail('projection-provision-file-config-required');
  const selectedPath = secretFile(ref);
  const privatePath = secretFile('file:' + join(await realpath(dirname(selectedPath)), basename(selectedPath)));
  if (privatePath === resolve(publicPath)) fail('projection-key-paths-must-differ');
  // Fail before generating if either target already exists. Recovery is explicit.
  for (const path of [privatePath, resolve(publicPath)]) {
    try { await stat(path); fail('projection-key-target-already-exists'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
  const pair = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  for (const [path, key, type, mode] of [[privatePath, pair.privateKey, 'pkcs8', 0o600], [resolve(publicPath), pair.publicKey, 'spki', 0o644]]) {
    const handle = await open(path, 'wx', mode);
    try { await handle.writeFile(key.export({ type, format: 'pem' })); await handle.sync(); } finally { await handle.close(); }
  }
  await loadConfiguredProjectionSigner(env);
  return { ok: true, keyId: env.UTOPY_IDENTITY_PROJECTION_KEY_ID, publicKeyFile: resolve(publicPath) };
}
